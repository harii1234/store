//
//  SearchVC.swift
//  StoreNxt
//
//  Created by hari Prasath on 21/01/19.
//  Copyright © 2019 hari Prasath. All rights reserved.
//

import UIKit
import CoreData

class SearchVC: UIViewController,UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate {
   
    @IBOutlet weak var tbview: UITableView!
    @IBOutlet var txt_searchfield: ACFloatingTextfield!
    @IBOutlet weak var back_btn: UIButton!


    var ProdcutArray = [ProductDetails]()
    var prodcutBackup = [ProductDetails]()
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
    var categoryarray = [Data]()
    var tasks: [CartEntity] = []
    var dummy_arr = [Data]()
    var seen = [String]()
    var productfilteredArray = NSArray() //to store filtered data
    var productarr_1 = NSArray() //to store Whole data
    var categoryProduct = [Data]()
    var productarr = [Data]()
    var product = [String]() //to store Whole data
    var product_id = [String]() //to store Whole data
    var dataArray=[String]()
    var price_arr = [Double]()
    var Item_id=[String]()
    var ImgArray=[String]()
    var isLiked:Bool!
    var sectionindex = Int()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.tbview.isHidden = true
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        txt_searchfield.selectedPlaceHolderColor = primary_theme
        txt_searchfield.selectedLineColor = primary_theme
        self.tbview.rowHeight = UITableView.automaticDimension;
        self.tbview.estimatedRowHeight = 44.0;
        print(categoryProduct_1.count)
        back_btn.tintColor = primary_theme
            self.getitems()
    }
    override func viewDidAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        network.reachability.whenUnreachable = { reachability in
            //self.showOfflinePage()
        }

    }
    func showOfflinePage()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "InternetVC") as! InternetVC
        self.present(vc, animated: true, completion: nil)
    }
    
     @IBAction func back_action(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func RequestParam() -> NSMutableDictionary
    {
        
        let param = NSMutableDictionary()
        
        param["tag"] =  "getItemsByStore"
        param["store_name"] = store_name
        
        
        print("param \(param)")
        return param
    }
    
    func getitems()
    {
        
        for item in categoryProduct_1
        {
            self.dataArray.append(item.name!)
            self.Item_id.append(item.item_id!)
            self.ImgArray.append(item.image_path!)
            self.price_arr.append((item.unit_price as! NSString).doubleValue)
            
        }
        
        self.cartgetData()
        if self.ProdcutArray.count > 0 {
            self.ProdcutArray.removeAll()
        }
        for i in 0..<self.dataArray.count {
            let isQntyUpdated = self.tasks.filter( { $0.product_id == self.Item_id[i] } )
            var prd: ProductDetails!
            if isQntyUpdated.count > 0 {
                prd = ProductDetails(productName: self.dataArray[i], productId: self.Item_id[i] , productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: self.price_arr[i], originalPrice: self.price_arr[i], Productimage: self.ImgArray[i])
                //ProdcutDetails(productName: dataArray[i], productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: price_arr[i], originalPrice: price_arr[i])
                print(prd)
            } else {
                prd = ProductDetails(productName: self.dataArray[i], productId: self.Item_id[i], productCount: 0, productPrice: self.price_arr[i], originalPrice: self.price_arr[i],Productimage: self.ImgArray[i] )
                //ProdcutDetails(productName: dataArray[i], productCount: 0, productPrice: price_arr[i], originalPrice: price_arr[i])
            }
            self.ProdcutArray.append(prd)
        }
        print(self.ProdcutArray.count)
        self.prodcutBackup = self.ProdcutArray
        self.tbview.isHidden = false
        
        self.tbview.reloadData()
        
    }
    
    //MARK:-APICALL
    func get_items() {
        
        getproduct_API(isloader: false, param: RequestParam(), withSuccessBlock: { (result) in
            //
            let root = ProductDataRoot.init(dictionary: result as! NSDictionary)
            if  root?.data != nil
            {
                let temp_arr = root?.data
                self.seen.removeAll()
                var unique = [Data]()
                for item in temp_arr!
                {
                    if !self.seen.contains(item.category!)
                    {
                        unique.append(item)
                        self.seen.append(item.category!)
                        //self.tax_str.append(item.tax_name!)
                    }
                    
                }
                //   self.categoryarray = unique
                print(temp_arr?.count)
                for item in temp_arr!
                {
                    self.product.append(item.name!)
                    self.product_id.append(item.item_id!)
                    self.categoryarray.append(item)
                }
                print(self.categoryarray.count)
                
                for item in self.categoryarray
                {
                    self.dataArray.append(item.name!)
                    self.Item_id.append(item.item_id!)
                    self.ImgArray.append(item.image_path!)
                    self.price_arr.append((item.unit_price as! NSString).doubleValue)
                    
                }
                
                self.cartgetData()
                if self.ProdcutArray.count > 0 {
                    self.ProdcutArray.removeAll()
                }
                for i in 0..<self.dataArray.count {
                    let isQntyUpdated = self.tasks.filter( { $0.product_id == self.Item_id[i] } )
                    var prd: ProductDetails!
                    if isQntyUpdated.count > 0 {
                        prd = ProductDetails(productName: self.dataArray[i], productId: self.Item_id[i] , productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: self.price_arr[i], originalPrice: self.price_arr[i], Productimage: self.ImgArray[i])
                        //ProdcutDetails(productName: dataArray[i], productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: price_arr[i], originalPrice: price_arr[i])
                        print(prd)
                    } else {
                        prd = ProductDetails(productName: self.dataArray[i], productId: self.Item_id[i], productCount: 0, productPrice: self.price_arr[i], originalPrice: self.price_arr[i],Productimage: self.ImgArray[i] )
                        //ProdcutDetails(productName: dataArray[i], productCount: 0, productPrice: price_arr[i], originalPrice: price_arr[i])
                    }
                    self.ProdcutArray.append(prd)
                }
                print(self.ProdcutArray.count)
                self.prodcutBackup = self.ProdcutArray
                self.tbview.isHidden = false

                self.tbview.reloadData()
                
                
            }
            
            
        }) { (error) in
            //
        }
    }
    
    // MARK: - Table view data source
    
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ProdcutArray.count;
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as! ProductListTableViewCell
        cell.ItemName.text=ProdcutArray[indexPath.row].productName
        cell.plusBtn.tag=indexPath.row
        cell.minusBtn.tag=indexPath.row
        cell.like_btn.tag = indexPath.row
        cell.currencycode.font = RegularText
        cell.ItemName.font = BoldText
        cell.lblNo.font = RegularText
        cell.price_lbl.font = RegularText
        cell.currencycode.text = currencycode
        cell.plusBtn.backgroundColor = primary_theme
        cell.minusBtn.backgroundColor = primary_theme
        cell.price_lbl.text = String(ProdcutArray[indexPath.row].productPrice ?? 0)
        cell.lblNo.text  = String(ProdcutArray[indexPath.row].productCount ?? 0)
        let fileUrl  = NSURL(string: ProdcutArray[indexPath.row].Productimage!)!
        print(fileUrl)
        cell.Itemimg!.sd_setImage(with: fileUrl as URL? , placeholderImage: #imageLiteral(resourceName: "cookies"))
        cell.plusBtn.addTarget(self, action: #selector(ProductListViewController.addBtn(sender:)), for: .touchUpInside)
        cell.minusBtn.addTarget(self, action: #selector(ProductListViewController.subBtn(sender:)), for: .touchUpInside)
        cell.like_btn.addTarget(self, action: #selector(ProductListViewController.likeBtn(sender:)), for: .touchUpInside)
        if ProdcutArray[indexPath.row].productCount == 0
        {
            cell.minusBtn.isHidden = true
            cell.lblNo.isHidden = true
            cell.minusBtn.backgroundColor = primary_theme_minusbtn
        }
        else
        {
            cell.minusBtn.isHidden = false
            cell.lblNo.isHidden = false
            cell.minusBtn.backgroundColor = primary_theme
        }
        if fav_array.contains(Int(ProdcutArray[indexPath.row].productId!)!)
        {
            cell.like_btn.setImage(UIImage(named: "liked"), for: UIControl.State())
            
        }
        else
        {
            cell.like_btn.setImage(UIImage(named: "like"), for: UIControl.State())
            
        }
        return cell
    }
    @objc func likeBtn(sender: SparkButton) {
        sender.isSelected = !sender.isSelected
        let indexPath = IndexPath.init(row: sender.tag, section: 0)
        let product = Int(ProdcutArray[indexPath.row].productId ?? "0")
        if sender.imageView?.image != UIImage(named: "liked")
        {
            sender.setImage(UIImage(named: "liked"), for: UIControl.State())
            sender.animate()
            sender.likeBounce(0.6)
            isLiked = false
            fav_array.append(product ?? 0)
            addfav()
        } else {
            sender.setImage(UIImage(named: "like"), for: UIControl.State())
            sender.likeBounce(0.4)
            isLiked = true
            fav_array = fav_array.filter({$0 != product})
            addfav()
        }
    }
    func FavRequestParam() -> NSMutableDictionary
    {
        
        let param = NSMutableDictionary()
        let receivings_data = NSMutableDictionary()
        
        
        param["tag"] = "addFavItemList"
        param["customer_id"] = user_id_str
        param["token_key"] = token_str
        receivings_data .setValue(fav_array, forKey: "item_list")
        param .setValue(receivings_data, forKey: "favourite_items")
        
        
        
        
        print("param \(param)")
        return param
    }
    
    
    func addfav()
    {
        addfav_API(param: FavRequestParam(), withSuccessBlock: { (result) in
            //
        }) { (error) in
            //
        }
        
    }
    @objc func addBtn(sender: AnyObject) {
        let indexPath = NSIndexPath(row: sender.tag, section: 0) // This defines what indexPath is which is used later to define a cell
        // Once you have the reference to the cell, just use the
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
        request.predicate = NSPredicate (format: "product_id == %@", ProdcutArray[indexPath.row].productId ?? "")
        do {
            let result = try context.fetch(request)
            var actualAmount =  Double()
            ProdcutArray[indexPath.row].productCount = (ProdcutArray[indexPath.row].productCount ?? 0) + 1
            let amnt = ProdcutArray[indexPath.row].originalPrice ?? 0.0
            let cnt =  ProdcutArray[indexPath.row].productCount ?? 0
            actualAmount = Double(Int(amnt) * cnt)
            //    ProdcutArray[indexPath.row].productPrice = Double(actualAmount)
            if result.count > 0 {
                let objectUpdate = result[0] as! NSManagedObject
                objectUpdate.setValue(ProdcutArray[indexPath.row].productCount ?? 0 + 1, forKey: "product_count")
                objectUpdate.setValue(actualAmount, forKey: "product_amount")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                do {
                    try context.save()
                    cartgetData()
                } catch {}
                print("Object Saved.")
            }
            else {
                let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                newproduct.setValue(ProdcutArray[indexPath.row].productCount, forKey: "product_count")
                newproduct.setValue(actualAmount, forKey: "product_amount")
                newproduct.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                newproduct.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                newproduct.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                do {
                    try context.save()
                    cartgetData()
                } catch {}
                
                print("Object Saved.")
            }
        }
        catch
        {
            print(error)
        }
        tbview.reloadData()
    }
    @objc func subBtn(sender: AnyObject) {
        let indexPath = NSIndexPath(row: sender.tag, section: 0) // This defines what indexPath is which is used later to define a cell
        // Once you have the reference to the cell, just use the
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
        request.predicate = NSPredicate (format: "product_id == %@", ProdcutArray[indexPath.row].productId ?? "")
        do {
            let result = try context.fetch(request)
            let cnt =  ProdcutArray[indexPath.row].productCount ?? 0
            if cnt > 0 {
                var actualAmount =  Double()
                ProdcutArray[indexPath.row].productCount = (ProdcutArray[indexPath.row].productCount ?? 0) - 1
                let amnt = ProdcutArray[indexPath.row].originalPrice ?? 0.0
                if ProdcutArray[indexPath.row].productCount == 0 {
                    
                    if result.count > 0
                    {
                        let objectUpdate = result[0] as! NSManagedObject
                        context.delete(objectUpdate)
                        (UIApplication.shared.delegate as! AppDelegate).saveContext()
                        do {
                            tasks = try context.fetch(CartEntity.fetchRequest())
                            cartgetData()
                        }
                        catch {
                            print("Fetching Failed")
                        }
                        print("Object Removed.")
                        
                        
                    }
                }
                else{
                    
                    actualAmount = Double(Int(amnt) * cnt)
                    //   ProdcutArray[indexPath.row].productPrice = Double(actualAmount)
                    if result.count > 0 {
                        let objectUpdate = result[0] as! NSManagedObject
                        objectUpdate.setValue(ProdcutArray[indexPath.row].productCount ?? 0, forKey: "product_count")
                        objectUpdate.setValue(actualAmount, forKey: "product_amount")
                        objectUpdate.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                        objectUpdate.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                        objectUpdate.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                        do {
                            try context.save()
                            cartgetData()
                            
                        } catch {}
                        print("Object Saved.")
                    }
                    else {
                        let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                        newproduct.setValue(ProdcutArray[indexPath.row].productCount, forKey: "product_count")
                        newproduct.setValue(actualAmount, forKey: "product_amount")
                        newproduct.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                        newproduct.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                        newproduct.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                        do {
                            try context.save()
                            cartgetData()
                        } catch {}
                        
                        print("Object Saved.")
                    } }
            } else {
                print("Value less than zero")
            }
        }
        catch {
            print(error)
        }
        tbview.reloadData()
    }
    
    
    func update(type:String,Index:Int)
    {
        
    }
    
    
    
    func cartgetData() {
        
        do {
            
            tasks = try context.fetch(CartEntity.fetchRequest())
            print(tasks.count)
            var total_count:Int = 0
            for item in tasks
            {
                total_count = total_count + Int(item.product_count)
            }
            print(total_count)
            let badgeValue = tasks.count
            if badgeValue == 0 {
                tabBarController?.tabBar.items?[2].badgeValue = nil
            }  else {
                tabBarController?.tabBar.items?[2].badgeValue = String(total_count)
            }
            
        }
        catch {
            print("Fetching Failed")
        }
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        let string1 = string
        let string2 = txt_searchfield.text
        var finalString = ""
        if string.count > 0 { // if it was not delete character
            finalString = string2! + string1
        }
        else if txt_searchfield.text != ""
        { // if it was a delete character
            ProdcutArray = prodcutBackup
            finalString = String(string2!.characters.dropLast())
        }
        
        if textField.text != ""
        {
            tbview.isHidden = false
        }
        
        filteredArray(searchString: finalString as String)// pass the search String in this method
        
        
        
        return true
    }
    
    func filteredArray(searchString:String)
    {// we will use NSPredicate to find the string in array
        let predicate = NSPredicate(format: "SELF contains[c] %@",searchString) // This will give all element of array which contains search string
        //let predicate = NSPredicate(format: "SELF BEGINSWITH %@",searchString)// This will give all element of array which begins with search string (use one of them)
       // ProdcutArray = ProdcutArray.filter({ ($0.productName?.contains(searchString))! })
        ProdcutArray = ProdcutArray.filter { ($0.productName?.localizedCaseInsensitiveContains(searchString))! }
        //filter({ ($0.productName?.contains(text ?? ""))! })
        if(ProdcutArray.count == 0){
            ProdcutArray = prodcutBackup
        }
        self.tbview.reloadData()
        // view_height.constant = tbview.contentSize.height
        print(filteredArray)
    }
    

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Show the navigation bar on other view controllers
        self.navigationController?.setNavigationBarHidden(false, animated: true)
    }

}
