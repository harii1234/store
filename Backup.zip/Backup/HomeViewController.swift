//
//  HomeViewController.swift
//  StoreNxt
//
//  Created by hari Prasath on 27/10/18.
//  Copyright © 2018 hari Prasath. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UIGestureRecognizerDelegate, UICollectionViewDelegateFlowLayout, UITableViewDelegate, UITableViewDataSource {





    @IBOutlet weak var offer_collectionview: UICollectionView!
    @IBOutlet weak var category_collectionview: UICollectionView!
    @IBOutlet weak var category_tableview: UITableView!

    @IBOutlet weak var categorycollection_height: NSLayoutConstraint!
    @IBOutlet weak var scroll_height: NSLayoutConstraint!
    @IBOutlet weak var page_control: UIPageControl!
    @IBOutlet var view_ShimmerForCarcollection: UIView!
    var array = NSMutableArray()
    let cart_count = UserDefaults.standard
    var categoryarray = [Data]()
    var categoryProduct = [Data]()
    var seen = [String]()
    var tax_str = [String]()
    var productarr = [Data]()
    var product = [String]() //to store Whole data
    var product_id = [String]() //to store Whole data
    var productfilteredArray = NSArray() //to store filtered data
    var productarr_1 = NSArray() //to store Whole data

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let badgeValue = cart_count.value(forKey: "cart_value") as! Int
        if badgeValue == 0 {
            tabBarController?.tabBar.items?[2].badgeValue = nil
        } else {
            tabBarController?.tabBar.items?[2].badgeValue = String(badgeValue)
        }

        self.navigationItem.title = "Home"
        self.category_tableview.isHidden = true
        self.getitem(Loader: true)
        updatetoken()


    }
    func updatedevicetokenParam() -> NSMutableDictionary
    {
        
        let param = NSMutableDictionary()
        
        param["tag"] = "updateDeviceToken"
        param["customer_id"] = user_id_str
        param["token_key"] = token_str
        param["device_token"] = fCMtoken

        
        
        
        print("param \(param)")
        return param
    }
    
    func updatetoken()
    {
        updatedevicetoken_API(param: updatedevicetokenParam(), withSuccessBlock: { (result) in
            //
        }) { (error) in
            //
        }
        
    }

    override func viewWillAppear(_ animated: Bool) {
        network.reachability.whenUnreachable = { reachability in
            //self.showOfflinePage()
        }
        self.getfavitem()
       self.getitem(Loader: false)


    }
    func showOfflinePage()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "InternetVC") as! InternetVC
        self.present(vc, animated: true, completion: nil)
    }
    func FavRequestParam() -> NSMutableDictionary
    {

        let param = NSMutableDictionary()

        param["tag"] = "getFavItemList"
        param["customer_id"] = user_id_str
        param["token_key"] = token_str



        print("param \(param)")
        return param
    }

    func getfavitem()
    {
        getfav_API(isloader: false, param: FavRequestParam(), withSuccessBlock: { (result) in
                //
                let favroot = FavRoot.init(dictionary: result as! NSDictionary)
            if favroot?.status == true{
            if let val = favroot?.data {
                  fav_array = val
            }
            }
            else
            {
                self.alert(message: (favroot?.message)!)
            }
            }) { (error) in
            //
        }
    }


    @IBAction func search_Action(_ sender: Any) {
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(viewController, animated: true)
    }



    // MARK: - COllectionDelegates

    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        if collectionView == offer_collectionview
        {

            return 5

        }
        else
        {
            return seen.count

        }



    }

    func getitem(Loader:Bool)
    {
        getproduct_API(isloader: Loader, param: RequestParam(), withSuccessBlock: { (result) in
                //
                let root = ProductDataRoot.init(dictionary: result as! NSDictionary)
                if root?.data != nil
                {
                    let temp_arr = root?.data
                    self.categoryarray.removeAll()
                    self.categoryarray = (root?.data)!

                    self.seen.removeAll()
                    var unique = [Data]()
                    for item in temp_arr!
                    {
                        
                        if !self.seen.contains(item.category!)
                        {
                            unique.append(item)
                            self.seen.append(item.category!)
                            //self.tax_str.append(item.tax_name!)
                        }

                    }
                    //  self.categoryarray = unique
                    favnamearray.removeAll()
                    category.removeAll()
                    category = self.categoryarray
                    for item in category
                    {
                        if fav_array.contains(Int(item.item_id!)!)
                        {
                            favnamearray.append(item)
                        }
                    }

                  print(favnamearray)
                     self.categoryProduct.removeAll()
                    for item in temp_arr!
                    {
                        self.product.append(item.name!)
                        self.product_id.append(item.item_id!)
                        self.categoryProduct.append(item)
                    }
                    categoryProduct_1.removeAll()
                    categoryProduct_1 = self.categoryProduct
                    print(categoryProduct_1.count)
                    print(self.product)
                    self.productarr_1 = self.product as NSArray
                    // self.category_collectionview.reloadData()
                    self.category_tableview.isHidden = false
                    self.category_tableview.reloadData()
                }

                }) { (error) in
                //
            }


        }


        func RequestParam() -> NSMutableDictionary
        {

            let param = NSMutableDictionary()

            param["tag"] = "getItemsByStore"
            param["store_name"] = store_name


            print("param \(param)")
            return param
        }

        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            if collectionView == offer_collectionview
            {

                let cell: HomeCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "offercell", for: indexPath) as! HomeCollectionViewCell
                self.setheight()
                return cell
            }
            else
            {
                let cell: HomeCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: "categorycell", for: indexPath) as! HomeCollectionViewCell

                cell.custom_view.layer.cornerRadius = 5.0
                cell.custom_view.layer.borderColor = UIColor.lightGray.cgColor
                cell.custom_view.layer.borderWidth = 0.2
                cell.custom_view.layer.shadowColor = UIColor(red: 200 / 255.0, green: 200 / 255.0, blue: 200 / 255.0, alpha: 1.0).cgColor
                cell.custom_view.layer.shadowOpacity = 1.0
                cell.custom_view.layer.shadowRadius = 5.0
                cell.custom_view.layer.shadowOffset = CGSize.zero
                cell.category_lbl.text = seen[indexPath.row]
                self.setheight()

                return cell
            }


        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {

            if collectionView == offer_collectionview
            {
                return 20;

            } else
            {
                return 20;
            }


        }

        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {

            if collectionView == offer_collectionview
            {
                return 10;

            } else
            {
                return 0;
            }

        }


        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {



            if(collectionView == self.offer_collectionview)
            { let screenSize = UIScreen.main.bounds.size
                var screenWidth_org = screenSize.width
                var screenWidth = screenSize.width
                screenWidth = screenWidth - 40


                return CGSize(width: screenWidth, height: 143)



            }
            else
            {
                return CGSize(width: (UIScreen.main.bounds.size.width - 70) / 2, height: 155)
            }


        }


        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            if collectionView == offer_collectionview
            {
                return UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)

            }
            else
            {
                return UIEdgeInsets(top: 10, left: 25, bottom: 40, right: 25)
            }
        }

        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 50
        }

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return seen.count
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell: HomeTableViewCell = tableView.dequeueReusableCell(withIdentifier: "categorycell", for: indexPath) as! HomeTableViewCell

            cell.category_lbl.text = seen[indexPath.row]
            cell.category_lbl.font = BoldText
            return cell
        }

        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let cat_name = self.seen[indexPath.row]
            var item_arr = [Data]()
            for item in categoryarray
            {
                if item.category == cat_name
                {
                    item_arr.append(item)
                }

            }

            let productvc = self.storyboard?.instantiateViewController(withIdentifier: "ProductListViewController") as! ProductListViewController
            productvc.categoryarray = item_arr
            self.navigationController?.pushViewController(productvc, animated: true)
        }

        //  public func mapView(_ mapView: MKMapView, didChange mode: MKUserTrackingMode, animated: Bool)

        public func shouldInvalidateLayoutForBoundsChange(newBounds: CGRect) -> Bool {
            return true
        }



        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            if collectionView == category_collectionview
            {
                let cat_name = self.seen[indexPath.row]
                var item_arr = [Data]()
                for item in categoryarray
                {
                    if item.category == cat_name
                    {
                        item_arr.append(item)
                    }

                }

                let productvc = self.storyboard?.instantiateViewController(withIdentifier: "ProductListViewController") as! ProductListViewController
                productvc.categoryarray = item_arr
                self.navigationController?.pushViewController(productvc, animated: true)

            }
        }



        func setheight() {
            //   categorycollection_height.constant = category_collectionview.contentSize.height
            // scroll_height.constant = category_collectionview.contentSize.height + 200
        }




    }
