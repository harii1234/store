//
//  ProductViewController.swift
//  CoredAtaDemo
//
//  Created by Mac User on 10/3/18.
//  Copyright © 2018 Mac User. All rights reserved.
//

import UIKit
import CoreData
import SDWebImage

class ProductListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate {
    var dataArray=[String]()
    var ImgArray=[String]()
    var price_arr = [Double]()
    var Item_id=[String]()

    @IBOutlet weak var tbview: UITableView!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
    @IBOutlet weak var searchbar: Customsearchbar!
    var tasks: [CartEntity] = []
    var ProdcutArray = [ProductDetails]()
    var prodcutBackup = [ProductDetails]()
    var type = String()
    var categoryarray = [Data]()
    var isLiked:Bool!
    var sectionindex = Int()
   
    @IBOutlet weak var topspace: NSLayoutConstraint!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.navigationItem.title = type
        self.searchbar.barTintColor = primary_theme
        self.navigationItem.title = "Products"
        self.tbview.rowHeight = UITableView.automaticDimension;
        self.tbview.estimatedRowHeight = 44.0;
        tbview.allowsSelection = false
        searchbar.isHidden = true
        topspace.constant = -64
        //calculateTotal()

    }
    override func viewWillAppear(_ animated: Bool) {
        setdata()
        network.reachability.whenUnreachable = { reachability in
            //self.showOfflinePage()
        }

    }
    func showOfflinePage()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "InternetVC") as! InternetVC
        self.present(vc, animated: true, completion: nil)
    }
    
    func setdata()
    {
        var seen = Set<String>()
        var unique = [Data]()
        self.dataArray.removeAll()
        self.Item_id.removeAll()
        self.ImgArray.removeAll()
        self.price_arr.removeAll()
        for item in categoryarray
        {
            if !seen.contains(item.item_id!)
            {
                unique.append(item)
                // self.categoryarray.append(item)
                seen.insert(item.item_id!)
                //   seen.append(item.category!)
            }
 

            
        }
        self.categoryarray = unique
       
        for item in self.categoryarray
        {
            dataArray.append(item.name!)
            Item_id.append(item.item_id!)
            ImgArray.append(item.image_path!)
            price_arr.append((item.unit_price as! NSString).doubleValue)

        }
        
        self.cartgetData()
        if ProdcutArray.count > 0 {
            ProdcutArray.removeAll()
        }
        for i in 0..<dataArray.count {
            let isQntyUpdated = tasks.filter( { $0.product_id == Item_id[i] } )
            var prd: ProductDetails!
            if isQntyUpdated.count > 0 {
                prd = ProductDetails(productName: dataArray[i], productId: Item_id[i] , productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: price_arr[i], originalPrice: price_arr[i], Productimage: ImgArray[i] )
                    //ProdcutDetails(productName: dataArray[i], productCount: Int(isQntyUpdated.first?.product_count ?? 0) , productPrice: price_arr[i], originalPrice: price_arr[i])
                print(prd)
            } else {
                prd = ProductDetails(productName: dataArray[i], productId: Item_id[i], productCount: 0, productPrice: price_arr[i], originalPrice: price_arr[i], Productimage: ImgArray[i])
                    //ProdcutDetails(productName: dataArray[i], productCount: 0, productPrice: price_arr[i], originalPrice: price_arr[i])
            }
            ProdcutArray.append(prd)
        }
        prodcutBackup = ProdcutArray
        
        tbview.reloadData()
    }
 
    
    @IBAction func search_action(_ sender: Any) {
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    
    
    
    
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
    }
    
    func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchbar.isHidden = true
        searchbar.text = ""
        topspace.constant = -64
        searchbar.resignFirstResponder()
        
        // ProdcutArray = prodcutBackup
      //  self.tbview.reloadData()

    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        let text = searchbar.text?.lowercased()
        ProdcutArray = ProdcutArray.filter({ ($0.productName?.contains(text!))! })
        //filter({ ($0.productName?.contains(text ?? ""))! })
        if(ProdcutArray.count == 0){
            ProdcutArray = prodcutBackup
        }
        self.tbview.reloadData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK: - Table view data source

    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return ProdcutArray.count;
      
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as! ProductListTableViewCell
            cell.ItemName.text=ProdcutArray[indexPath.row].productName
            cell.plusBtn.tag=indexPath.row
            cell.minusBtn.tag=indexPath.row
            cell.like_btn.tag = indexPath.row
            cell.plusBtn.backgroundColor = primary_theme
            cell.minusBtn.backgroundColor = primary_theme
            cell.currencycode.font = RegularText
            cell.ItemName.font = BoldText
            cell.lblNo.font = RegularText
            cell.price_lbl.font = RegularText
            cell.currencycode.text = currencycode
            let fileUrl  = NSURL(string: ProdcutArray[indexPath.row].Productimage!)!
            print(fileUrl)
            cell.Itemimg!.sd_setImage(with: fileUrl as URL? , placeholderImage: #imageLiteral(resourceName: "cookies"))
            cell.price_lbl.text = String(ProdcutArray[indexPath.row].productPrice ?? 0)
            cell.lblNo.text  = String(ProdcutArray[indexPath.row].productCount ?? 0)

              if ProdcutArray[indexPath.row].productCount == 0
              {
                cell.minusBtn.isHidden = true
                cell.lblNo.isHidden = true
                cell.minusBtn.backgroundColor = primary_theme_minusbtn
        }
        else
              {
                cell.minusBtn.isHidden = false
                cell.lblNo.isHidden = false
                cell.minusBtn.backgroundColor = primary_theme
        }
        
            cell.plusBtn.addTarget(self, action: #selector(ProductListViewController.addBtn(sender:)), for: .touchUpInside)
            cell.minusBtn.addTarget(self, action: #selector(ProductListViewController.subBtn(sender:)), for: .touchUpInside)
          cell.like_btn.addTarget(self, action: #selector(ProductListViewController.likeBtn(sender:)), for: .touchUpInside)
       
        if fav_array.contains(Int(ProdcutArray[indexPath.row].productId!)!)
        {
            cell.like_btn.setImage(UIImage(named: "liked"), for: UIControl.State())
            
        }
        else
        {
            cell.like_btn.setImage(UIImage(named: "like"), for: UIControl.State())
            
        }
            return cell
    }
    @objc func likeBtn(sender: SparkButton) {
        sender.isSelected = !sender.isSelected
        let indexPath = IndexPath.init(row: sender.tag, section: 0)
        let product = Int(ProdcutArray[indexPath.row].productId ?? "0")
        if sender.imageView?.image != UIImage(named: "liked")
        {
            sender.setImage(UIImage(named: "liked"), for: UIControl.State())
            sender.animate()
            sender.likeBounce(0.6)
            isLiked = false
            fav_array.append(product ?? 0)
            addfav()
        } else {
            sender.setImage(UIImage(named: "like"), for: UIControl.State())
            sender.likeBounce(0.4)
            isLiked = true
            fav_array = fav_array.filter({$0 != product})
            addfav()
        }
    }
    @objc func addBtn(sender: AnyObject) {
            let indexPath = NSIndexPath(row: sender.tag, section: 0) // This defines what indexPath is which is used later to define a cell
            // Once you have the reference to the cell, just use the
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
            request.predicate = NSPredicate (format: "product_id == %@", ProdcutArray[indexPath.row].productId ?? "")
            do {
                let result = try context.fetch(request)
                var actualAmount =  Double()
                ProdcutArray[indexPath.row].productCount = (ProdcutArray[indexPath.row].productCount ?? 0) + 1
                let amnt = ProdcutArray[indexPath.row].originalPrice ?? 0.0
                let cnt =  ProdcutArray[indexPath.row].productCount ?? 0
                actualAmount = Double(Int(amnt) * cnt)
            //    ProdcutArray[indexPath.row].productPrice = Double(actualAmount)
                if result.count > 0 {
                    let objectUpdate = result[0] as! NSManagedObject
                    objectUpdate.setValue(ProdcutArray[indexPath.row].productCount ?? 0 + 1, forKey: "product_count")
                    objectUpdate.setValue(actualAmount, forKey: "product_amount")
                    objectUpdate.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                     objectUpdate.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                    objectUpdate.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                    do {
                        try context.save()
                        cartgetData()
                    } catch {}
                    print("Object Saved.")
                }
                else {
                    let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                    newproduct.setValue(ProdcutArray[indexPath.row].productCount, forKey: "product_count")
                    newproduct.setValue(actualAmount, forKey: "product_amount")
                    newproduct.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                    newproduct.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                    newproduct.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                    do {
                        try context.save()
                        cartgetData()
                    } catch {}
                    
                    print("Object Saved.")
                }
            }
            catch
            {
                print(error)
            }
        tbview.reloadData()
    }
    @objc func subBtn(sender: AnyObject) {
        let indexPath = NSIndexPath(row: sender.tag, section: 0) // This defines what indexPath is which is used later to define a cell
        // Once you have the reference to the cell, just use the
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
        request.predicate = NSPredicate (format: "product_id == %@", ProdcutArray[indexPath.row].productId ?? "")
        do {
            let result = try context.fetch(request)
            let cnt =  ProdcutArray[indexPath.row].productCount ?? 0
            if cnt > 0 {
            var actualAmount =  Double()
            ProdcutArray[indexPath.row].productCount = (ProdcutArray[indexPath.row].productCount ?? 0) - 1
            let amnt = ProdcutArray[indexPath.row].originalPrice ?? 0.0
                if ProdcutArray[indexPath.row].productCount == 0 {
            
                    if result.count > 0
                    {
                        let objectUpdate = result[0] as! NSManagedObject
                        context.delete(objectUpdate)
                        (UIApplication.shared.delegate as! AppDelegate).saveContext()
                        do {
                            tasks = try context.fetch(CartEntity.fetchRequest())
                            cartgetData()
                        }
                        catch {
                            print("Fetching Failed")
                        }
                        print("Object Removed.")
                        
                        
                    }
                }
                else{
                
            actualAmount = Double(Int(amnt) * cnt)
         //   ProdcutArray[indexPath.row].productPrice = Double(actualAmount)
            if result.count > 0 {
                let objectUpdate = result[0] as! NSManagedObject
                objectUpdate.setValue(ProdcutArray[indexPath.row].productCount ?? 0, forKey: "product_count")
                objectUpdate.setValue(actualAmount, forKey: "product_amount")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                objectUpdate.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                do {
                    try context.save()
                    cartgetData()
                    
                } catch {}
                print("Object Saved.")
            }
            else {
                let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                newproduct.setValue(ProdcutArray[indexPath.row].productCount, forKey: "product_count")
                newproduct.setValue(actualAmount, forKey: "product_amount")
                newproduct.setValue(ProdcutArray[indexPath.row].productName, forKey: "product_name")
                newproduct.setValue(ProdcutArray[indexPath.row].productId, forKey: "product_id")
                newproduct.setValue(ProdcutArray[indexPath.row].productPrice, forKey: "product_originalamount")
                do {
                    try context.save()
                    cartgetData()
                } catch {}
                
                print("Object Saved.")
                    } }
                } else {
                print("Value less than zero")
            }
        }
        catch {
            print(error)
        }
        tbview.reloadData()
    }
    func FavRequestParam() -> NSMutableDictionary
    {
        
        let param = NSMutableDictionary()
        let receivings_data = NSMutableDictionary()

        
        param["tag"] = "addFavItemList"
        param["customer_id"] = user_id_str
        param["token_key"] = token_str
        receivings_data .setValue(fav_array, forKey: "item_list")
        param .setValue(receivings_data, forKey: "favourite_items")
        
      

        
        print("param \(param)")
        return param
    }

    
    func addfav()
    {
        addfav_API(param: FavRequestParam(), withSuccessBlock: { (result) in
            //
        }) { (error) in
            //
        }
        
    }
    
    func update(type:String,Index:Int)
    {
        
    }
    
    
 
    func cartgetData() {
        
        do {
            
            tasks = try context.fetch(CartEntity.fetchRequest())
            print(tasks.count)
            var total_count:Int = 0
            for item in tasks
            {
                total_count = total_count + Int(item.product_count)
            }
            print(total_count)
             let badgeValue = tasks.count
            if badgeValue == 0 {
                tabBarController?.tabBar.items?[2].badgeValue = nil
            }  else {
                tabBarController?.tabBar.items?[2].badgeValue = String(total_count)
            }
            
        }
        catch {
            print("Fetching Failed")
        }
    }
    
}

struct ProductDetails {
    var productName: String?
    var productId: String?
    var productCount: Int?
    var productPrice: Double?
    var originalPrice: Double?
    var Productimage: String?

}
