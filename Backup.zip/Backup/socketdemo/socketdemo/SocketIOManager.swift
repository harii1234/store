//
//  SocketIOManager.swift
//  SocketChat
//
//  Created by Gabriel Theodoropoulos on 1/31/16.
//  Copyright © 2016 AppCoda. All rights reserved.
//

import UIKit
import SocketIO

class SocketIOManager: NSObject {
    static let sharedInstance = SocketIOManager()
    
    let manager = SocketManager(socketURL: URL(string: "https://socket-io-chat.now.sh/")!, config: [.log(true),.compress,.forcePolling(true),.forceWebsockets(true)])
    
    
//    let manager = SocketManager(socketURL: URL(string: "http://192.168.1.55:4000")!, config: [.log(true),.compress,.forcePolling(true),.forceWebsockets(true)])
    
//     let manager = SocketManager(socketURL: URL(string: "https://socket-io-chat.now.sh")!, config: [.log(true),.compress,.forcePolling(true),.forceWebsockets(true)])
    
    
    override init() {
        super.init()
    }
    
    
    func establishConnection() {
        manager.defaultSocket.connect()
        
        manager.defaultSocket.onAny { (event) in
            print("EVENT : - \(event.event)")
            print("EVENT Description : - \(event.description)")
                    }
    }
    
    
    func closeConnection() {
        manager.defaultSocket.disconnect()
    }
    
    
    func connectToServerWithNickname(nickname: String, completionHandler: @escaping (_ userList: [[String: AnyObject]]?) -> Void) {
        //manager.defaultSocket.emit("connectUser", nickname)
        manager.defaultSocket.emit("add user", nickname)
        
        //manager.defaultSocket.on("userList") { ( dataArray, ack) -> Void in
        manager.defaultSocket.on("login") { ( dataArray, ack) -> Void in
            completionHandler(dataArray[0] as? [[String: AnyObject]])
        }
    
        listenForOtherMessages()
    }
    
    
    func exitChatWithNickname(nickname: String, completionHandler: @escaping () -> Void) {
       // manager.defaultSocket.emit("exitUser", nickname)
        
        
//        manager.defaultSocket.on("disconnect") { (dataArray, socketAck) -> Void in
//
//            self.manager.defaultSocket.emit("user left", nickname)
//
//            completionHandler()
//        }
        
        let dic = NSMutableDictionary()
        dic["username"] = nickname
        let arr = NSMutableArray()
        arr.add(dic)
        manager.defaultSocket.emit("disconnect", arr)
       // manager.defaultSocket.emit("user left", nickname)
        completionHandler()
    }
    
    
    func sendMessage(message: String, withNickname nickname: String) {
        
        //manager.defaultSocket.emit("chatMessage", nickname, message)
 
        manager.defaultSocket.emit("new message", message)
       
    }
    
    
    func getChatMessage(completionHandler: @escaping (_ messageInfo: [String: AnyObject]) -> Void) {
        
        
        
        //manager.defaultSocket.on("newChatMessage") { (dataArray, socketAck) -> Void in
        manager.defaultSocket.on("new message") { (dataArray, socketAck) -> Void in
        
            let messageDictionary =  dataArray[0] as! [String: AnyObject]
            
            
//          messageDictionary["username"] = dataArray[0] as! String as AnyObject
//          messageDictionary["message"] = dataArray[1] as! String as AnyObject
//          messageDictionary["date"] = dataArray[2] as! String as AnyObject as AnyObject
            print(dataArray)
           completionHandler(messageDictionary)
        }
    }
    
    
    private func listenForOtherMessages() {
      //  manager.defaultSocket.on("userConnectUpdate") { (dataArray, socketAck) -> Void in
          manager.defaultSocket.on("user joined") { (dataArray, socketAck) -> Void in
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "userWasConnectedNotification"), object: dataArray[0] as! [String: AnyObject])
        }
        
       // manager.defaultSocket.on("userExitUpdate") { (dataArray, socketAck) -> Void in
        manager.defaultSocket.on("user left") { (dataArray, socketAck) -> Void in
        
        
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "userWasDisconnectedNotification"), object: dataArray[0] as! [String: AnyObject] )
        }
        
       // manager.defaultSocket.on("userTypingUpdate") { (dataArray, socketAck) -> Void in
         manager.defaultSocket.on("typing") { (dataArray, socketAck) -> Void in
            
            var dic = NSMutableDictionary()
            dic = dataArray[0] as! NSMutableDictionary
            dic["type"] = "start"
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "userTypingNotification"), object: dic as? [String: AnyObject])
        }
        
        manager.defaultSocket.on("stop typing") { (dataArray, socketAck) -> Void in
            
            var dic = NSMutableDictionary()
            dic = dataArray[0] as! NSMutableDictionary
            dic["type"] = "stop"
            
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "userTypingNotification"), object: dic as? [String: AnyObject])
        }
        
    }
    
    
    func sendStartTypingMessage(nickname: String) {
        //manager.defaultSocket.emit("startType", nickname)
        
        let dic = NSMutableDictionary()
        dic["username"] = nickname
        let arr = NSMutableArray()
        arr.add(dic)
        manager.defaultSocket.emit("typing", arr)
    }
    
    
    func sendStopTypingMessage(nickname: String) {
       // manager.defaultSocket.emit("stopType", nickname)
        
        var dic = NSMutableDictionary()
        dic["username"] = nickname
        var arr = NSMutableArray()
        arr.add(dic)
        manager.defaultSocket.emit("stop typing", arr)
    }
}
