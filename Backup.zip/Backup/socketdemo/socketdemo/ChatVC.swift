//
//  ChatVC.swift
//  socketdemo
//
//  Created by KrishnaPradeep on 24/01/18.
//  Copyright © 2018 hariprasath. All rights reserved.
//

import UIKit
import JSQMessagesViewController


struct User {
    
    let id: String
    let name: String
    
    
}

class ChatVC: JSQMessagesViewController {

    
    
    
    @IBOutlet weak var lblOtherUserActivityStatus: UILabel!
    
    @IBOutlet weak var lblNewsBanner: UILabel!
    
    
    var nickname: String!
    
    var chatMessages = [[String: AnyObject]]()
    
    var bannerLabelTimer: Timer!
    
    
    var user1 :User! = nil
    
    let user2 :User! = nil
    
    var currentUser :User!  = nil
    
//    var currentUser: User {
//        return user1
//    }
    
    // all messages of users1, users2
    var messages = [JSQMessage]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //JSQ Setup
//        self.senderId = currentUser.id
//        self.senderDisplayName = currentUser.name

        self.user1 = User(id: nickname, name: nickname)
        self.currentUser = self.user1
        self.senderId = nickname
        self.senderDisplayName = nickname
        //self.messages = getMessages()
        
        //SOKET Setup
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleConnectedUserUpdateNotification(notification:)), name: NSNotification.Name(rawValue: "userWasConnectedNotification"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleDisconnectedUserUpdateNotification(notification:)), name: NSNotification.Name(rawValue: "userWasDisconnectedNotification"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleUserTypingNotification(notification:)), name: NSNotification.Name(rawValue: "userTypingNotification"), object: nil)
        
        
    }
    
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //configureNewsBannerLabel()
        //configureOtherUserActivityLabel()
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        SocketIOManager.sharedInstance.getChatMessage { (messageInfo) -> Void in
            
            DispatchQueue.main.async(execute: {
                
                let user_id = messageInfo["username"] as! String
                let name = messageInfo["username"] as! String
                let message = messageInfo["message"] as! String

               self.messages = self.reciveedMessages(_id: user_id, name: name, message: message)
                self.collectionView.reloadData()
                
            })
            
        }
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    
    
    
    // MARK: Custom Methods
 
    
    // MARK: IBAction Methods
    
    
    
    
    func configureNewsBannerLabel() {
        lblNewsBanner.layer.cornerRadius = 15.0
        lblNewsBanner.clipsToBounds = true
        lblNewsBanner.alpha = 0.0
    }
    
    
    func configureOtherUserActivityLabel() {
        lblOtherUserActivityStatus.isHidden = true
        lblOtherUserActivityStatus.text = ""
    }
    
   
    
    
    
    
    
    func showBannerLabelAnimated() {
        UIView.animate(withDuration: 0.75, animations: { () -> Void in
            self.lblNewsBanner.alpha = 1.0
            
        }) { (finished) -> Void in
            self.bannerLabelTimer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(self.hideBannerLabel), userInfo: nil, repeats: false)
        }
    }
    
    
    @objc func hideBannerLabel() {
        if bannerLabelTimer != nil {
            bannerLabelTimer.invalidate()
            bannerLabelTimer = nil
        }
        
        UIView.animate(withDuration: 0.75, animations: { () -> Void in
            self.lblNewsBanner.alpha = 0.0
            
        }) { (finished) -> Void in
        }
    }
    
    
    
    
    
    @objc func handleConnectedUserUpdateNotification(notification: NSNotification) {
//        let connectedUserInfo = notification.object as! [String: AnyObject]
//        let connectedUserNickname = connectedUserInfo["username"] as? String
//        lblNewsBanner.text = "User \(connectedUserNickname!.uppercased()) was just connected."
//        showBannerLabelAnimated()
    }
    
    
    @objc func handleDisconnectedUserUpdateNotification(notification: NSNotification) {
        
//        let disconnectedUserInfo = notification.object as! [String: AnyObject]
//        let disconnectedUserNickname = disconnectedUserInfo["username"] as? String
//
//        lblNewsBanner.text = "User \((disconnectedUserNickname!.uppercased())) has left."
//        showBannerLabelAnimated()
    }
    
    
    @objc func handleUserTypingNotification(notification: NSNotification) {
//        if let typingUsersDictionary = notification.object as? [String: AnyObject] {
//
//            let typingUserInfo = notification.object as! [String: AnyObject]
//            let typingUsertype = typingUserInfo["type"] as? String
//            let typingUserInfoUserNickname = typingUserInfo["username"] as? String
//
//
//            if typingUsertype == "start"{
//
//                lblOtherUserActivityStatus.text = "\((typingUserInfoUserNickname)!) is now typing a message..."
//                lblOtherUserActivityStatus.isHidden = false
//            }
//            else {
//                lblOtherUserActivityStatus.isHidden = true
//            }
//
//        }
        
    }
    
    
    
    
    // MARK: UITextViewDelegate Methods
    
    override func textViewShouldBeginEditing(_ textView: UITextView) -> Bool {
        SocketIOManager.sharedInstance.sendStartTypingMessage(nickname: nickname)
        
        return true
    }
    
    var timer: Timer? = nil
    
    
    override func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        
        SocketIOManager.sharedInstance.sendStartTypingMessage(nickname: nickname)
        
        timer?.invalidate()
        timer = Timer.scheduledTimer(
            timeInterval: 0.5,
            target: self,
            selector: #selector(self.getHints),
            userInfo: ["textView": textView],
            repeats: false)
        return true
    }
    
    @objc func getHints(timer: Timer) {
        
        SocketIOManager.sharedInstance.sendStopTypingMessage(nickname: nickname)
        
        //        var userInfo = timer.userInfo as! [String: UITextField]
        //        print("Hints for textField: \(userInfo["textField"])")
    }


}





extension ChatVC {
    
    override func didPressSend(_ button: UIButton!, withMessageText text: String!, senderId: String!, senderDisplayName: String!, date: Date!) {
        
        
        let message = JSQMessage(senderId: senderId, displayName: senderDisplayName, text: text)
        
        messages.append(message!)
        
        SocketIOManager.sharedInstance.sendMessage(message: text, withNickname: (message?.senderDisplayName)!)
        
        finishSendingMessage()
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, attributedTextForMessageBubbleTopLabelAt indexPath: IndexPath!) -> NSAttributedString! {
        let message = messages[indexPath.row]
        let messageUsername = message.senderDisplayName
        
        return NSAttributedString(string: messageUsername!)
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, layout collectionViewLayout: JSQMessagesCollectionViewFlowLayout!, heightForMessageBubbleTopLabelAt indexPath: IndexPath!) -> CGFloat {
        return 15
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, avatarImageDataForItemAt indexPath: IndexPath!) -> JSQMessageAvatarImageDataSource! {
        return nil
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageBubbleImageDataForItemAt indexPath: IndexPath!) -> JSQMessageBubbleImageDataSource! {
        let bubbleFactory = JSQMessagesBubbleImageFactory()
        
        let message = messages[indexPath.row]
        
        if currentUser.id == message.senderId {
            return bubbleFactory?.outgoingMessagesBubbleImage(with: .green)
        } else {
            return bubbleFactory?.incomingMessagesBubbleImage(with: .blue)
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    override func collectionView(_ collectionView: JSQMessagesCollectionView!, messageDataForItemAt indexPath: IndexPath!) -> JSQMessageData! {
    
        
        return messages[indexPath.row]
    }
    
    
    
    func getMessages() -> [JSQMessage] {
        var messages = [JSQMessage]()
        
        let message1 = JSQMessage(senderId: "1", displayName: "Steve", text: "Hey Tim how are you?")
        let message2 = JSQMessage(senderId: "2", displayName: "Tim", text: "Fine thanks, and you?")
        
        messages.append(message1!)
        messages.append(message2!)
        
        return messages
    }
    
    
    func reciveedMessages(_id:String, name:String, message:String) -> [JSQMessage] {
        

        let message = JSQMessage(senderId: _id, displayName: name, text: message)

        self.messages.append(message!)

        return messages
        
        
    }
    
}
