//
//  ViewController.swift
//  socketdemo
//
//  Created by hariprasath on 20/01/18.
//  Copyright © 2018 hariprasath. All rights reserved.
//

import UIKit
import SocketIO


class ViewController: UIViewController {

    
//    let manager = SocketManager(socketURL: URL(string: "http://192.168.1.55:4000")!, config: [.log(true),.compress,.forcePolling(true),.forceWebsockets(true),.forceNew(true),.connectParams(["username":"hari@!$"])])
    

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
//
//         manager.defaultSocket.on(clientEvent: .connect) {data, ack in
//            print("socket connected")
//
//
//
//        }
//
//         manager.defaultSocket.on(clientEvent: .disconnect) {data, ack in
//            print("socket Disconnected")
//        }
//
//         manager.defaultSocket.on(clientEvent: .error) {data, ack in
//            print("socket Error")
//        }
//
//         manager.defaultSocket.on(clientEvent: .statusChange) {data, ack in
//            print("socket statusChange")
//        }
        
        

        
//        manager.defaultSocket.on("currentAmount") {data, ack in
//            guard let cur = data[0] as? Double else { return }
//
//            self.manager.defaultSocket.emitWithAck("canUpdate", cur).timingOut(after: 0) {data in
//                self.manager.defaultSocket.emit("chat", ["amount": cur + 2.50])
//            }
//
//            ack.with("Got your currentAmount", "dude")
//        }
        
//         manager.defaultSocket.onAny { (event) in
//            print(event.description)
//        }
//         manager.defaultSocket.connect()

       
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
//    @IBAction func send_action(_ sender: UIButton) {
//        
//        self.manager.defaultSocket.emit("chat", "Hi this is Loge!!")
//    }
    

}

