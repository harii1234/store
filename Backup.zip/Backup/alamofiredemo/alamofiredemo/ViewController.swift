//
//  ViewController.swift
//  alamofiredemo
//
//  Created by hariprasath on 30/08/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

   /* var temp = NSArray()
    var dic = NSDictionary()
 */

    var temp = [Results]()
    
    @IBOutlet var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }
    override func viewWillAppear(_ animated: Bool) {
        self.getUserDetails()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        print(self.temp.count)
        return self.temp.count
    }
    

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)   as! TableViewCell
        myCell.backgroundColor = UIColor.gray
        
        let dic = self.temp[indexPath.row]
        myCell.textLabel?.text = dic.trackCensoredName
        myCell.textLabel?.textColor = UIColor.white
     
        return myCell
    }

    
    func getUserDetails()
    {
        APIHandler.shared.getdetails(withSuccess: { (result) in
            //
            var dataroot = Dataroot.init(dictionary: result as! NSDictionary)
            self.temp = (dataroot?.results)!
            self.tableview.reloadData()
        }) { (error) in
            //
        }
    }
    
    
  /*  public func getUserDetails() {
        
        let url = "https://itunes.apple.com/search?term=jack+johnson"
        print("url: \(url)")
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
            
            
            .validate(statusCode: 200..<400)
            .responseJSON { response in
                
                switch response.result {
                case .success :
                    if let result = response.result.value {
                        let JSON = result as! NSDictionary
                        print("responds\(JSON)")
                       self.temp =  JSON.value(forKey: "results") as! NSArray
                        self.tableview.reloadData()
                        print(self.temp)
                        print(self.temp.count)
                        
                       
                  for value in self.temp
                   {
                  
                    self.dic = value as! NSDictionary
                    let name = self.dic.object(forKey: "trackCensoredName")
                    print(name!)
                    
                        }
                    
                    }
                    
                case .failure(let error): break
                
                    // sending to failure block
                    }

                    
                    
                }
        }
 */
    
    
    }




