

import UIKit
import Alamofire


 // MARK: - BaseURL Live





class APIHandler: NSObject
{
    
    
    
    static let shared = APIHandler()
   
    public func getdetails(withSuccess successBlock: @escaping ((AnyObject) -> Void), andFailureBlock failBlock: @escaping((Error) -> Void)) {
        
        
        let url = "https://itunes.apple.com/search?term=jack+johnson"
        print("url: \(url)")
        
        
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default, headers : nil)
       

            
            .validate(statusCode: 200..<400)
            .responseJSON { response in
                
                switch response.result {
                case .success :
                    if let result = response.result.value {
                        let JSON = result as? AnyObject
                        
                       print(JSON)
                        
                     
                        successBlock(JSON!)
                        
                    }
                    
                case .failure(let error):
                    // sending to failure block
                    
                    print(error.localizedDescription)
                    failBlock(error)
                }
                
        }
        
    }
    

}
