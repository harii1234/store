//
//  ViewController.swift
//  SampleSwift
//
//  Created by qbuser on 30/01/17.
//  Copyright © 2017 vigneshuvi. All rights reserved.
//

import UIKit
import Foundation
import MessageUI


class Task: NSObject {
    var date: String = ""
    var name: String = ""
    var startTime: String = ""
    var endTime: String = ""
}


class ViewController: UIViewController,MFMailComposeViewControllerDelegate {
    
    var taskArr = [Task]()
    var task: Task!
    var path = NSURL()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        task = Task()
        for _ in 0..<52 {
            task.name = "Raj"
            task.date = "\(Date())"
            task.startTime = "Start \(Date())"
            task.endTime = "End \(Date())"
            taskArr.append(task!)
        }
        
        creatCSV()
    }
    
    // MARK: CSV file creating
    func creatCSV() -> Void {
        let fileName = "Tasks.csv"
        path = NSURL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent(fileName)! as NSURL
        var csvText = "Date,Task Name,Time Started,Time Ended\n"
        
        for task in taskArr {
            let newLine = "\(task.date),\(task.name),\(task.startTime),\(task.endTime)\n"
            csvText.append(newLine)
        }
        
        do {
            try csvText.write(to: path as URL, atomically: true, encoding: String.Encoding.utf8)
                //csvText.write(to: path!, automically: true, encoding: String.Encoding.utf8)
        } catch {
            print("Failed to create file")
            print("\(error)")
        }
        print(path)
    }
    
    @IBAction func btn_Action(_ sender: Any) {
  
     sendMail()
        
    }
    
   
    
    func sendMail() {
        if MFMailComposeViewController.canSendMail()
        {
            if( MFMailComposeViewController.canSendMail()){
                print("Can send email.")
                
                let mailComposer = MFMailComposeViewController()
                mailComposer.mailComposeDelegate = self
                
                //Set to recipients
             //   mailComposer.setToRecipients(["yakupad@yandex.com"])
                
                //Set the subject
                mailComposer.setSubject("email with document pdf")
                
                //set mail body
                mailComposer.setMessageBody("This is what they sound like.", isHTML: true)
                let pathPDF = "\(NSTemporaryDirectory())Tasks.csv"
                if let fileData = NSData(contentsOfFile: pathPDF)
                {
                    print("File data loaded.")
                    mailComposer.addAttachmentData(fileData as Data, mimeType: "application/pdf", fileName: "Tasks.csv")
                }
                
                //this will compose and present mail to user
                self.present(mailComposer, animated: true, completion: nil)
            }
            else
            {
                print("email is not supported")
            }
        }
    }
    func mailComposeController(_ didFinishWithcontroller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        self.dismiss(animated: true, completion: nil)
    }

}
    

