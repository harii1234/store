//
//  CartViewController.swift
//  CoredAtaDemo
//
//  Created by Mac User on 10/3/18.
//  Copyright © 2018 Mac User. All rights reserved.
//

import UIKit
import CoreData
import Razorpay


class CartViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,RazorpayPaymentCompletionProtocol, ExternalWalletSelectionProtocol {
    
    var value=["0","0","0","0","0"]
    var price=["0","0","0","0","0"]
    var amount = Int()
    var window: UIWindow?
    var orderid = Int()
    @IBOutlet weak var tbview: UITableView!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    let AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
    var paymentid = String()
    var tasks: [CartEntity] = []
    var type = String()
    var product_array = NSMutableArray()
    var originalproduct_array = NSMutableArray()
    let dic_AllValues = NSMutableDictionary()
    @IBOutlet weak var checkout_btn: Custombutton!
    @IBOutlet weak var checkoutlater_btn: Custombutton!
    private var razorpay: Razorpay?
   let ud = UserDefaults.standard
    @IBOutlet weak var totalamount_lbl: UILabel!
    @IBOutlet weak var total_lbl: UILabel!
    var COD_payment:Bool = true
    var addresslist = [Addresslist]()
    var address_str = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        presentWindow = UIApplication.shared.keyWindow

        tbview.allowsSelection = false
        self.navigationItem.title = "Cart"
        checkout_btn.setTitleColor(buttontitlecolour, for: .normal)
        checkout_btn.backgroundColor = primary_theme
        checkoutlater_btn.setTitleColor(buttontitlecolour, for: .normal)
        checkoutlater_btn.backgroundColor = primary_theme
        checkout_btn.titleLabel?.font = BoldText
        checkoutlater_btn.titleLabel?.font = BoldText
        razorpay = Razorpay.initWithKey(KEY_ID, andDelegate: self)
        razorpay?.setExternalWalletSelectionDelegate(self)
        //calculateTotal()
    }
    override func viewWillAppear(_ animated: Bool) {
        network.reachability.whenUnreachable = { reachability in
            //self.showOfflinePage()
        }
        self.getaddress()
        getData()


    }
    func showOfflinePage()
    {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "InternetVC") as! InternetVC
        self.present(vc, animated: true, completion: nil)
    }
    // MARK: - Table view data source
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        // #warning Incomplete implementation, return the number of rows
       
        return product_array.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath as IndexPath) as! ProductListTableViewCell
        
        let obj_dic = product_array.object(at: indexPath.row) as! NSDictionary
        
        cell.ItemName.text=obj_dic.value(forKey: "product_name") as! String
        cell.lblNo.text = obj_dic.value(forKey: "product_count") as! String
        cell.price_lbl.text = obj_dic.value(forKey: "product_amount") as! String
        cell.plusBtn.tag=indexPath.row
        cell.minusBtn.tag=indexPath.row
        cell.deleteBtn.tag=indexPath.row
        cell.currencycode.text = currencycode
        cell.deleteBtn.tintColor = primary_theme
        cell.plusBtn.backgroundColor = primary_theme
        cell.minusBtn.backgroundColor = primary_theme
        cell.currencycode.font = RegularText
        cell.ItemName.font = BoldText
        cell.lblNo.font = RegularText
        cell.price_lbl.font = RegularText
        cell.currencycode.text = currencycode
        cell.original_price_lbl.text = obj_dic.value(forKey: "product_originalamount") as! String
        cell.plusBtn.addTarget(self, action: #selector(CartViewController.addBtn(sender:)), for: .touchUpInside)
        cell.minusBtn.addTarget(self, action: #selector(CartViewController.subBtn(sender:)), for: .touchUpInside)
        cell.deleteBtn.addTarget(self, action: #selector(CartViewController.deleteaction(sender:)), for: .touchUpInside)
        
        
        
        return cell
    }
    
    @objc func deleteaction(sender: UIButton){
        showAlertView("Are you sure to remove Product from cart.?", tag: sender.tag)

       
    }
    
   
    func showAlertView(_ message:String,tag:Int)
    {
        
        let alert = UIAlertController(title: nil, message: message, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Delete", style: UIAlertAction.Style.destructive, handler: { (ACTION :UIAlertAction!)in
            
            self.context.delete(self.tasks[tag])
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            do {
                self.tasks = try self.context.fetch(CartEntity.fetchRequest())
            }
            catch {
                print("Fetching Failed")
            }
            self.getData()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { (ACTION :UIAlertAction!)in
            
            alert.dismiss(animated: true, completion: nil)
            
        }))
        
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
   
    @objc func addBtn(sender: AnyObject) -> Int {
        //var count:NSInteger=0;
        //let button: UIButton = sender as! UIButton
        
        let indexPath = NSIndexPath(row: sender.tag, section: 0) // This defines what indexPath is which is used later to define a cell
        var count1=Int()
        let cell = tbview.cellForRow(at: indexPath as IndexPath) as! ProductListTableViewCell! // This is where the magic happens - reference to the cell
        count1 = Int(cell?.lblNo.text ?? "0")!
        count1 = 1 + count1
        
        print(count1)
        cell?.lblNo.text = "\(count1)" // Once you have the reference to the cell, just use the traditional way of setting up the objects inside the cell.
        
        var price=Int(self.price[indexPath.row])!;
        price = Int(Double(cell?.original_price_lbl.text ?? "0")!)
        price =  count1 * price
        
        var product_price = Double(price)
        cell?.price_lbl.text = "\(product_price)"
        
        let obj_dic = product_array.object(at: indexPath.row) as! NSDictionary
        
        
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
        request.predicate = NSPredicate (format: "product_id == %@", obj_dic.value(forKey: "product_id") as! String)
        let product_id = obj_dic.value(forKey: "product_id")
        do
        {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let objectUpdate = result[0] as! NSManagedObject
                
                objectUpdate.setValue(count1, forKey: "product_count")
                objectUpdate.setValue(product_id, forKey: "product_id")
                objectUpdate.setValue(product_price, forKey: "product_amount")
                
                do {
                    try context.save()
                    
                    
                } catch {}
                
                print("Object Saved.")
                
                
            }
            else
            {
                
                let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                newproduct.setValue(count1, forKey: "product_count")
                newproduct.setValue(product_id, forKey: "product_id")
                newproduct.setValue(product_price, forKey: "product_amount")

                do {
                    try context.save()
                } catch {}
                
                print("Object Saved.")
            }
        }
        catch
        {
            print(error)
        }
        
        
        getData()
        return count
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    
    @objc func subBtn(sender: AnyObject) -> Int {
        //var count1:NSInteger=0;
        //let button: UIButton = sender as! UIButton
        
        let indexPath = NSIndexPath(row: sender.tag, section: 0)
        var count=Int(value[indexPath.row])!;
        let cell = tbview.cellForRow(at: indexPath as IndexPath) as! ProductListTableViewCell!
        count = Int(cell?.lblNo.text ?? "0")!
        count = count - 1
        
        print(count)
        if count == 0 {
            NSLog("Count zero")
            value[indexPath.row]=String(count);
            cell?.lblNo.text = "\(count)"
            let task = tasks[indexPath.row]
            context.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            do {
                tasks = try context.fetch(CartEntity.fetchRequest())
            }
            catch {
                print("Fetching Failed")
            }
            getData()
        }else if count > 0 {
            value[indexPath.row]=String(count);
            cell?.lblNo.text = "\(count)"
            var price=Int(self.price[indexPath.row])!;
            price = Int(Double(cell?.original_price_lbl.text ?? "0")!)
            price =  count * price
            
            var product_price = Double(price)
            cell?.price_lbl.text = "\(product_price)"

            let obj_dic = product_array.object(at: indexPath.row) as! NSDictionary
            
            
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "CartEntity")
            request.predicate = NSPredicate (format: "product_id == %@", obj_dic.value(forKey: "product_id") as! String)
            let product_id = obj_dic.value(forKey: "product_id")
            do
            {
                let result = try context.fetch(request)
                if result.count > 0
                {
                    let objectUpdate = result[0] as! NSManagedObject
                    
                    objectUpdate.setValue(count, forKey: "product_count")
                    objectUpdate.setValue(product_id, forKey: "product_id")
                    objectUpdate.setValue(product_price, forKey: "product_amount")

                    do {
                        try context.save()
                        
                        
                    } catch {}
                    
                    print("Object Saved.")
                    
                    
                }
                else
                {
                    
                    let newproduct = NSEntityDescription.insertNewObject(forEntityName: "CartEntity", into: context) as NSManagedObject
                    newproduct.setValue(count, forKey: "product_count")
                    newproduct.setValue(product_id, forKey: "product_id")
                    newproduct.setValue(product_price, forKey: "product_amount")

                    do {
                        try context.save()
                        
                    } catch {}
                    
                    print("Object Saved.")
                }
            }
            catch
            {
                print(error)
            }
        }
        getData()
        return count
    }
    
    
    func getData() {
        
        do {
            
            tasks = try context.fetch(CartEntity.fetchRequest())
            product_array.removeAllObjects()
            originalproduct_array.removeAllObjects()
           
            
            if tasks.count > 0
            {
                self.tbview.isHidden = false
                self.checkout_btn.isHidden = false
                self.checkoutlater_btn.isHidden = false
                self.total_lbl.isHidden = false
                self.totalamount_lbl.isHidden = false

                for item in tasks
                {
                    let product_dic = NSMutableDictionary()
                    let original_dic = NSMutableDictionary()
                    
                    let productid = item.product_id
                    let data = item.product_name
                    let count = item.product_count
                    let product_price = item.product_amount
                    let original_price = item.product_originalamount
                    print("name:\(String(describing: data!))","Count:\(count)")
                    product_dic.setValue(productid, forKey: "product_id")
                    product_dic.setValue(data, forKey: "product_name")
                    product_dic.setValue(String(count), forKey: "product_count")
                    product_dic.setValue(String(product_price), forKey: "product_amount")
                    product_dic.setValue(String(original_price), forKey: "product_originalamount")
                    product_array.add(product_dic)
                    
                    original_dic.setValue(productid, forKey: "item_id")
                    original_dic.setValue(data, forKey: "item_name")
                    original_dic.setValue(String(count), forKey: "quantity")
                    original_dic.setValue(String(original_price), forKey: "price")
                    originalproduct_array.add(original_dic)
                }
                
                let receivings_data = NSMutableDictionary()
                
                receivings_data .setValue(originalproduct_array, forKey: "order_data")
                dic_AllValues .setValue(receivings_data, forKey: "orders")
                
                
                print(dic_AllValues)
                
                var overallTotal : Int = 0
                var total_product:Int = 0
                for item in tasks
                {
                    let totalWhole : Int = Int (item.product_amount)
                    overallTotal = overallTotal + totalWhole
                    total_product = total_product + Int(item.product_count)
                }
                print(overallTotal)
                amount = overallTotal
                totalamount_lbl.text = "\(currencycode) \(String(amount))"
                totalamount_lbl.font = MediumText
                total_lbl.font = RegularText
                let badgeValue = tasks.count
                if badgeValue == 0 {
                    tabBarController?.tabBar.items?[2].badgeValue = nil
                }  else {
                    tabBarController?.tabBar.items?[2].badgeValue = String(total_product)
                }
                tbview.reloadData()
            }
            else{
               
                tabBarController?.tabBar.items?[2].badgeValue = nil
                self.tbview.isHidden = true
                self.checkout_btn.isHidden = true
                self.checkoutlater_btn.isHidden = true
                self.total_lbl.isHidden = true
                self.totalamount_lbl.isHidden = true

            }
           
        }
        catch {
            print("Fetching Failed")
        }
    }
    
    
    @IBAction func paynow_action(_ sender: Any) {
        if address_str != ""
        {
            COD_payment = false
            dic_AllValues .setValue("saveOrderDetails", forKey: "tag")
            dic_AllValues .setValue("14", forKey: "store_id")
            dic_AllValues .setValue(amount, forKey: "total_amount")
            dic_AllValues .setValue(user_id_str, forKey: "user_id")
            dic_AllValues .setValue(token_str, forKey: "token_key")
            dic_AllValues .setValue("", forKey: "payment_id")
            dic_AllValues .setValue("", forKey: "payment_status")
            dic_AllValues .setValue("application/json", forKey: "Content-Type")
            dic_AllValues .setValue(self.address_str, forKey: "address")
            
            
            print(dic_AllValues)
            request(body: dic_AllValues as! [String : Any])
        }
        else
        {
            
            let DeliveryAddressVC = self.storyboard?.instantiateViewController(withIdentifier: "DeliveryAddressVC") as! DeliveryAddressVC
            DeliveryAddressVC.isfromedit = false
            DeliveryAddressVC.address_count = 0
            self.navigationController?.pushViewController(DeliveryAddressVC, animated: true)
            
        }
    
    }
    
    @IBAction func checkout_action(_ sender: Any) {
        
       if address_str != ""
       {
        
        COD_payment = true
        dic_AllValues .setValue("saveOrderDetails", forKey: "tag")
        dic_AllValues .setValue(amount, forKey: "total_amount")
        dic_AllValues .setValue("14", forKey: "store_id")
        dic_AllValues .setValue(user_id_str, forKey: "user_id")
        dic_AllValues .setValue(token_str, forKey: "token_key")
        dic_AllValues .setValue("", forKey: "payment_id")
        dic_AllValues .setValue("cod", forKey: "payment_status")
        dic_AllValues .setValue("application/json", forKey: "Content-Type")
        dic_AllValues .setValue(self.address_str, forKey: "address")
        
        
        print(dic_AllValues)
        request(body: dic_AllValues as! [String : Any])
        }
        else
       {
        
        let DeliveryAddressVC = self.storyboard?.instantiateViewController(withIdentifier: "DeliveryAddressVC") as! DeliveryAddressVC
        DeliveryAddressVC.isfromedit = false
        DeliveryAddressVC.address_count = 0
        self.navigationController?.pushViewController(DeliveryAddressVC, animated: true)
        
        }
     
        
        
    }
    
    func request(body: [String: Any])
    {
        var url = String()
        
      /*  UIView.hr_setToastThemeColor(color: loader_primary_theme)
        presentWindow = UIApplication.shared.keyWindow
        presentWindow!.makeToastActivity()
 */
        Loading.shared.showLoading(loadingmessage: "")

        
            url = "\(baseurl)customer/saveOrderDetails"
        
        // prepare json data
        let json: [String: Any] = body
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        
        
        let jsonString = String(data: jsonData!, encoding: .utf8)
        print(jsonString)
        
        // create post request
        let url_1 = URL(string: url)!
        var request = URLRequest(url: url_1)
        request.httpMethod = "POST"
        request.setValue("IOS", forHTTPHeaderField: "X-DEVICE-TYPE")

        // insert json data to the request
        request.httpBody = jsonString?.data(using: String.Encoding.utf8)
        print(jsonData)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                print(responseJSON)
                let result_data:NSDictionary = responseJSON as NSDictionary
                let status = result_data.value(forKey: "status") as! Bool
                let message  = result_data.value(forKey: "message")
                
                DispatchQueue.main.async {
                    if status == false
                    {
                      /*  presentWindow!.makeToast(message: message as! String, duration: 2, position: "center" as AnyObject)
                        presentWindow?.hideToastActivity()
 */
                        Loading.shared.showLoadingWithMessage(message: message as! String)
                        Loading.shared.hideLoading()
                        if message as! String == "Login to Continue."
                        {
                            self.Logoutaction()
                        }
                        
                    }
                    else{
                        /* presentWindow!.makeToast(message: message as! String, duration: 2, position: "center" as AnyObject)
                        presentWindow?.hideToastActivity()
 */
                        Loading.shared.showLoadingWithMessage(message: message as! String)
                        Loading.shared.hideLoading()
                        if self.COD_payment == true
                        {
                            deleteAllRecords()
                            let when = DispatchTime.now() + 1
                            DispatchQueue.main.asyncAfter(deadline: when) {
                                let order:Int = result_data.value(forKey: "order_id") as! Int
                                let razorpay_order_id:String = result_data.value(forKey: "razorpay_order_id") as! String

                                self.getData()
                                self.orderid = order
                                self.OrderSuccesAlert(withTitle: "Order Status", andMessage: "Your order saved successfully and your order id is \(self.orderid)", orderid: "\(self.orderid)")

                                
                            }
                            
                        }
                        else
                        {
                            let when = DispatchTime.now() + 1
                            DispatchQueue.main.asyncAfter(deadline: when) {
                                let order:Int = result_data.value(forKey: "order_id") as! Int
                                self.getData()
                                self.orderid = order
                                self.OrderSuccesAlert(withTitle: "Order Status", andMessage: "Your order saved successfully and your order id is \(self.orderid)", orderid: "\(self.orderid)")
                                
                            }
                        }
                        


                    }
                    
                }
                
            }
        }
        
        task.resume()
    }
    
    func updatepaymentrequest(body: [String: Any])
    {
        var url = String()
        
     /*   UIView.hr_setToastThemeColor(color: loader_primary_theme)
        presentWindow = UIApplication.shared.keyWindow
        presentWindow!.makeToastActivity()
 */
        Loading.shared.showLoading(loadingmessage: "")
        
        url = "\(baseurl)customer/updatePaymentStatus"
        
        // prepare json data
        let json: [String: Any] = body
        
        let jsonData = try? JSONSerialization.data(withJSONObject: json)
        
        
        let jsonString = String(data: jsonData!, encoding: .utf8)
        print(jsonString)
        
        // create post request
        let url_1 = URL(string: url)!
        var request = URLRequest(url: url_1)
        request.httpMethod = "POST"
        request.setValue("IOS", forHTTPHeaderField: "X-DEVICE-TYPE")
        
        // insert json data to the request
        request.httpBody = jsonString?.data(using: String.Encoding.utf8)
        print(jsonData)
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            guard let data = data, error == nil else {
                print(error?.localizedDescription ?? "No data")
                return
            }
            let responseJSON = try? JSONSerialization.jsonObject(with: data, options: [])
            if let responseJSON = responseJSON as? [String: Any] {
                print(responseJSON)
                let result_data:NSDictionary = responseJSON as NSDictionary
                let status = result_data.value(forKey: "status") as! Bool
                let message  = result_data.value(forKey: "message")
                DispatchQueue.main.async {
                    if status == false
                    {
                      /*  presentWindow!.makeToast(message: message as! String, duration: 2, position: "center" as AnyObject)
                        presentWindow?.hideToastActivity()
 */
                        Loading.shared.showLoadingWithMessage(message: message as! String)
                        Loading.shared.hideLoading()
                        
                        if message as! String == "Login to Continue."
                        {
                            self.Logoutaction()
                        }
                        
                    }
                    else{
                      /*  presentWindow!.makeToast(message: message as! String, duration: 2, position: "center" as AnyObject)
                        presentWindow?.hideToastActivity()
 */
                        Loading.shared.showLoadingWithMessage(message: message as! String)
                        Loading.shared.hideLoading()
                       
                            deleteAllRecords()
                            let when = DispatchTime.now() + 1
                            DispatchQueue.main.asyncAfter(deadline: when) {
                                self.getData()
                               
                            }
                            
                     
                    }
                    
                }

            }
        }
        presentWindow?.hideToastActivity()

        task.resume()
    }
    
    
    //DELEGATE RAZORPAY
    func onExternalWalletSelected(_ walletName: String, WithPaymentData paymentData: [AnyHashable : Any]?) {
        presentWindow!.makeToast(message: String(format: EXTERNAL_METHOD_MESSAGE, walletName) , duration: 2, position: "center" as AnyObject)
       // showAlert(withTitle: EXTERNAL_METHOD_TITLE, andMessage: String(format: EXTERNAL_METHOD_MESSAGE, walletName))
        
    }
    
    func onPaymentError(_ code: Int32, description str: String) {
        presentWindow!.makeToast(message: String(format: str) , duration: 2, position: "center" as AnyObject)
      //  showAlert(withTitle: FAILURE_TITLE, andMessage: String(format: FAILURE_MESSAGE, code, str))
    }
    
    func onPaymentSuccess(_ payment_id: String) {
        Loading.shared.showLoadingWithMessage(message: SUCCESS_MESSAGE as! String)
//        presentWindow!.makeToast(message: SUCCESS_MESSAGE , duration: 2, position: "center" as AnyObject)
        paymentid = payment_id
        let ud = UserDefaults.standard
        let token = ud.value(forKey: "Token")
        let user_id = ud.value(forKey: "user_id")
        
        let dic_AllValues1 = NSMutableDictionary()

        dic_AllValues1 .setValue("updatePaymentStatus", forKey: "tag")
        dic_AllValues1 .setValue(paymentid, forKey: "payment_id")
        dic_AllValues1 .setValue("payment_success", forKey: "payment_status")
        dic_AllValues1 .setValue(orderid, forKey: "order_id")
        dic_AllValues1 .setValue(user_id, forKey: "user_id")
        dic_AllValues1 .setValue(token, forKey: "token_key")
        dic_AllValues1 .setValue("application/json", forKey: "Content-Type")

        
        updatepaymentrequest(body: dic_AllValues1 as! [String : Any])
    }
    
    func showAlert(withTitle:String,andMessage:String)
    {
        
      
            if UIDevice.current.systemVersion.compare("8.0", options: .numeric, range: nil, locale: .current) != .orderedAscending {
                var alert = UIAlertController(title: title, message: andMessage, preferredStyle: .alert)
                var cancelAction = UIAlertAction(title: OK_BUTTON_TITLE, style: .cancel, handler: nil)
                alert.addAction(cancelAction)
                present(alert, animated: true)
            } else {
                var alert = UIAlertView(title: title!, message: andMessage, delegate: nil, cancelButtonTitle: OK_BUTTON_TITLE, otherButtonTitles: "")
                alert.show()
            }
    }
    
    func OrderSuccesAlert(withTitle:String,andMessage:String,orderid:String)
    {
        if COD_payment == false
        {
        
        let alert = UIAlertController(title: withTitle, message: andMessage, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Paynow", style: UIAlertAction.Style.destructive, handler: { (ACTION :UIAlertAction!)in
            
            self.getData()
            print(self.amount)
            let amount_total = self.amount*100
             let amount_str = String(amount_total)
            let mobilenumber = self.ud.value(forKey: "mobile_number")
            let email_id = self.ud.value(forKey: "email_address")
             let options: [String:Any] = [
             "amount" : amount_str, //mandatory in paise
             "description": "Order id - \(orderid) ",
             "image": "https://url-to-image.png",
             "name": "products",
             "prefill": [
             "contact": mobilenumber,
             "email": email_id
             ],
             "theme": [
             "color": Razorpay_theme
             ]
             ]
            self.razorpay?.open(options)
            
            
            
            
            
        }))
        
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: { (ACTION :UIAlertAction!)in
            
            alert.dismiss(animated: true, completion: nil)
            
        }))
        
        
        self.present(alert, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: withTitle, message: andMessage, preferredStyle: UIAlertController.Style.alert)
            
            
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { (ACTION :UIAlertAction!)in
                
                alert.dismiss(animated: true, completion: nil)
                
            }))
            
            
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }
    
    
    
    
    
    func Logoutaction()
    {
        let userdefaults = UserDefaults.standard
        userdefaults .removeObject(forKey: "Token")
        userdefaults .removeObject(forKey: "userToken")
        userdefaults .removeObject(forKey: "mobile_number")
        userdefaults .removeObject(forKey: "email_address")
        userdefaults .removeObject(forKey: "user_id")
        userdefaults .removeObject(forKey: "firstname")
        userdefaults .removeObject(forKey: "lastname")
        deleteAllRecords()

        self.window = UIWindow(frame: UIScreen.main.bounds)
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoard.instantiateViewController(withIdentifier: "LoginVC") as! LoginVC
        let navigationController = UINavigationController(rootViewController: viewController)
        self.window?.rootViewController = navigationController
        self.window?.makeKeyAndVisible()
    }
    func RequestParam() -> NSMutableDictionary
    {
        
        let param = NSMutableDictionary()
        
        param["tag"] =  "viewDeliveryAddress"
        param["customer_id"] = user_id_str
        param["token_key"] = token_str
        
        
        
        print("param \(param)")
        return param
    }
    
    func getaddress()
    {
        getdeliveryaddress_API(Loader: false, param: RequestParam(), withSuccessBlock: { (result) in
            //
            let dataroot = Addresslistroot.init(dictionary: result as! NSDictionary)
            if dataroot?.status == true
            {
            if dataroot?.message == "Data found"
            {
                self.addresslist = (dataroot?.data)!
                for item in self.addresslist
                {
                    let address = item
                    if address.is_primary == 1
                    {
                        self.address_str = "\(String(describing: address.door_no!)),\(String(describing: address.address!)), \(String(describing: address.street_name!))"
                    }
                    
                }
          
            }
            else
            {
                self.address_str = ""
            }
            }
            else
            {
                self.alert(message: (dataroot?.message)!)
            }
            
        }) { (Error) in
            //
        }
    }
    
}
