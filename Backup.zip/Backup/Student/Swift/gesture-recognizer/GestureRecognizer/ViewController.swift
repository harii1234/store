//
//  ViewController.swift
//  GestureRecognizer
//
//  Created by TheAppGuruz-iOS-103 on 05/02/15.
//  Copyright (c) 2015 TheAppGururz. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{

    @IBOutlet weak var vwBox: UIView!
    
    var firstX:Double = 0;
    var firstY:Double = 0;
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.initializeGestureRecognizer()
    }
    
    func initializeGestureRecognizer()
    {
        //For TapGesture Recognization
        let tapGesture: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.recognizeTapGesture(_:)))
        vwBox.addGestureRecognizer(tapGesture)
        
        //For LongPressGesture Recoginzation
        let longPressedGesture: UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(ViewController.recognizeLongPressedGesture(_:)))
        vwBox.addGestureRecognizer(longPressedGesture)

        //For RotateGesture Recoginzation
        let rotateGesture: UIRotationGestureRecognizer = UIRotationGestureRecognizer(target: self, action: #selector(ViewController.recognizeRotateGesture(_:)))
        vwBox.addGestureRecognizer(rotateGesture)

        //For PinchGesture Recoginzation
        let pinchGesture: UIPinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: #selector(ViewController.recognizePinchGesture(_:)))
        vwBox.addGestureRecognizer(pinchGesture)

        //For PanGesture Recoginzation
        let panGesture: UIPanGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(ViewController.recognizePanGesture(_:)))
        panGesture.minimumNumberOfTouches = 1
        panGesture.maximumNumberOfTouches = 1
        vwBox.addGestureRecognizer(panGesture)
    }
    
    func recognizeTapGesture(_ sender: UIGestureRecognizer)
    {
        let colorRed: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        let colorGreen: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        let colorBlue: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        vwBox.backgroundColor = UIColor(red: colorRed, green: colorGreen, blue: colorBlue, alpha: 1)
    }
    
    func recognizeLongPressedGesture(_ sender: UILongPressGestureRecognizer)
    {
        let colorRed: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        let colorGreen: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        let colorBlue: CGFloat = CGFloat(arc4random()) / CGFloat(RAND_MAX)
        vwBox.backgroundColor = UIColor(red: colorRed, green: colorGreen, blue: colorBlue, alpha: 1)
    }
    
    func recognizeRotateGesture(_ sender: UIRotationGestureRecognizer)
    {
        sender.view!.transform = sender.view!.transform.rotated(by: sender.rotation)
        sender.rotation = 0
    }
    
    func recognizePinchGesture(_ sender: UIPinchGestureRecognizer)
    {
        sender.view!.transform = sender.view!.transform.scaledBy(x: sender.scale, y: sender.scale)
        sender.scale = 1
    }
    
    func recognizePanGesture(_ sender: UIPanGestureRecognizer)
    {
        let translate = sender.translation(in: self.view)
        sender.view!.center = CGPoint(x:sender.view!.center.x + translate.x,
            y:sender.view!.center.y + translate.y)
        sender.setTranslation(CGPoint.zero, in: self.view)
    }

}
