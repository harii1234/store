# gesture-recognizer-using-swift

Main objective of this blog to show you how to make an app in Swift Language and how to recognize gestures with Swift. Follow the steps and make your own Gesture recognition successful.

You can find complete tutorial on how to use the code repo here : [Gesture Recognizer using Swift](http://www.theappguruz.com/blog/gesture-recognizer-using-swift)

This Tutorial has been presented by The App Guruz - One of the best [iOS Development Company in India](http://www.theappguruz.com/iphone-app-development/)
