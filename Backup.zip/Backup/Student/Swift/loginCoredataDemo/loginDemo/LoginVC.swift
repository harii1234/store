//
//  LoginVC.swift
//  loginDemo
//
//  Created by hariprasath on 26/12/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import CoreData

class LoginVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    

    @IBOutlet var btn: UIButton!
    @IBOutlet var nametf: UITextField!
    @IBOutlet var passwordtf: UITextField!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var tableView: UITableView!

    var tasks: [UserEntity] = []
var id = Int()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnaction(_ sender: Any) {
        
        
        btn.backgroundColor = UIColor.brown
        btn .setTitle("signup", for: .normal)
        
        
    }
    @IBAction func login_action(_ sender: Any) {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserEntity")
        let searchString = self.nametf.text
        let searcghstring2 = self.passwordtf.text
        request.predicate = NSPredicate (format: "userName == %@", searchString!)
        do
        {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let   n = (result[0] as AnyObject).value(forKey: "userName") as! String
                let p = (result[0] as AnyObject).value(forKey: "password") as! String
                //  print(" checking")
                
                
                if (searchString == n && searcghstring2 == p)
                {
                    let userdetailVC = self.storyboard?.instantiateViewController(withIdentifier: "userdetailVC") as! userdetailVC
                    userdetailVC.myStringValue = nametf.text
//                    userdetailVC.myStringid = Int64(id)

                    self.nametf.text = ""
                    self.passwordtf.text = ""
                    self.navigationController?.pushViewController(userdetailVC, animated: true)
                    
                    
                  /*  let alertController1 = UIAlertController (title: "Access granted", message: "password correct ", preferredStyle: UIAlertControllerStyle.alert)
                    alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alertController1, animated: true, completion: nil)
 */
                }
                else if (searchString == n || searcghstring2 == p)
                {
                    // print("password incorrect ")
                    let alertController1 = UIAlertController (title: "no user found ", message: "password incorrect ", preferredStyle: UIAlertControllerStyle.alert)
                    alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alertController1, animated: true, completion: nil)
                }
            }
            else
            {
                let alertController1 = UIAlertController (title: "no user found ", message: "invalid username ", preferredStyle: UIAlertControllerStyle.alert)
                alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alertController1, animated: true, completion: nil)
                print("no user found")
            }
        }
        catch
        {
            print("error")
        }
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        getData()
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let task = tasks[indexPath.row]
            context.delete(task)
            (UIApplication.shared.delegate as! AppDelegate).saveContext()
            
            do {
                tasks = try context.fetch(UserEntity.fetchRequest())
            }
            catch {
                print("Fetching Failed")
            }
        }
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        let task = tasks[indexPath.row]
        
        if let myName = task.userName {
            cell.textLabel?.text = myName
        }
        
        return cell
    }
    
    func getData() {
        
        do {
            
            tasks = try context.fetch(UserEntity.fetchRequest())
        }
        catch {
            print("Fetching Failed")
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = UITableViewCell()
        
        let task = tasks[indexPath.row]
        
        if let myName = task.userName {
            nametf.text = myName
            passwordtf.text = task.password
            id = Int(task.id)
        }
        
    }
    
    

}
