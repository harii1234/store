//
//  SignupVC.swift
//  loginDemo
//
//  Created by hariprasath on 26/12/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import CoreData

class SignupVC: UIViewController {

    @IBOutlet var nametf: UITextField!
    @IBOutlet var passwordtf: UITextField!
    @IBOutlet var agetf: UITextField!
    @IBOutlet var emailtf: UITextField!
   
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func update_action(_ sender: Any) {
    }
    @IBAction func register_action(_ sender: Any) {
        
        
     /*   let userEmail = nametf.text
        let userPassword = passwordtf.text
     //   let userConfirmPassword = confirmPasswordTextField.text
        
        if ((userEmail?.isEmpty)! || (userPassword?.isEmpty)! ) {
            
            print("You haven't filled out all the fields.")
            return;
        }
        
        
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let managedContext = appDelegate.persistentContainer.viewContext
        let entity =  NSEntityDescription.entity(forEntityName: "UserEntity", in:managedContext)
        let item = NSManagedObject(entity: entity!, insertInto:managedContext)
        item.setValue(userEmail, forKey: "userName")
        item.setValue(userPassword, forKey: "password")
        do {
            print("Saved")
            try managedContext.save()
        } catch _ {
            print("Something went wrong.")
        }
 */
        
        
        if isValidInput(Input: nametf.text!)
        {
            if isPasswordValid(passwordtf.text!)
            {
                if isValidEmail(testStr: emailtf.text!)
                {
                    let n = Int(arc4random_uniform(42))

                    let _:AppDelegate = (UIApplication.shared.delegate as! AppDelegate)
                    let context:NSManagedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
                    let newUser = NSEntityDescription.insertNewObject(forEntityName: "UserEntity", into: context) as NSManagedObject
                    newUser.setValue(nametf.text, forKey: "userName")
                    newUser.setValue(passwordtf.text, forKey: "password")
                    newUser.setValue(emailtf.text, forKey: "email")
                    newUser.setValue(Int64(agetf.text!), forKey: "age")
                    newUser.setValue(n, forKey: "id")

                    do {
                        try context.save()
                    } catch {}
                    print(newUser)
                    print("Object Saved.")
                    let alertController1 = UIAlertController (title: "Valid ", message: "Sucess ", preferredStyle: UIAlertControllerStyle.alert)
                    alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alertController1, animated: true, completion: nil)
                    
                    
//                    let UserDetailsVc = self.storyboard?.instantiateViewController(withIdentifier: "logoutViewController") as! logoutViewController
//
//                    self.navigationController?.pushViewController(UserDetailsVc, animated: true)
                    
                }else
                {
                    print("mail check")
                    let alertController1 = UIAlertController (title: "Fill Email id", message: "Enter valid email", preferredStyle: UIAlertControllerStyle.alert)
                    
                    alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    present(alertController1, animated: true, completion: nil)
                }
            }
            else
            {
                print("pswd check")
                let alertController1 = UIAlertController (title: "Fill the password ", message: "Enter valid password", preferredStyle: UIAlertControllerStyle.alert)
                alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alertController1, animated: true, completion: nil)
            }
        }
        else
        {
            print("name check")
            
            let alertController1 = UIAlertController (title: "Fill the Name ", message: "Enter valid username", preferredStyle: UIAlertControllerStyle.alert)
            
            alertController1.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alertController1, animated: true, completion: nil)
        }
        
        
    }
    
    
    func isValidInput(Input:String) -> Bool
    {
        let RegEx = "\\A\\w{3,18}\\z"
        let Test = NSPredicate(format:"SELF MATCHES %@", RegEx)
        return Test.evaluate(with: Input)
    }
    func isPasswordValid(_ password : String) -> Bool{
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{3,}")
        return passwordTest.evaluate(with: password)
    }
    func isValidEmail(testStr:String) -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: testStr)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
