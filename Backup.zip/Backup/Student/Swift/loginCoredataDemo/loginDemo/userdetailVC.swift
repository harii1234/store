//
//  userdetailVC.swift
//  loginDemo
//
//  Created by hariprasath on 28/12/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import CoreData

class userdetailVC: UIViewController {

    @IBOutlet var nametf: UITextField!
    @IBOutlet var agetf: UITextField!
    @IBOutlet var emailtf: UITextField!
    var context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var myStringValue : String?
    var myStringid : Int?

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        showData()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    
    func showData()
    {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserEntity")
        request.predicate = NSPredicate (format: "userName == %@", myStringValue!)
        do
        {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let nameData = (result[0] as AnyObject).value(forKey: "userName") as! String
                let agedata = (result[0] as AnyObject).value(forKey: "age") as! Int64
                let emaildata = (result[0] as AnyObject).value(forKey: "email") as! String
                nametf.text = nameData
                emailtf.text = emaildata
                agetf.text = String(agedata)

            }
        }
        catch {
            //handle error
            print(error)
        }
    }
    
    @IBAction func update_action(_ sender: Any) {
        
        
        let empId = myStringValue
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "UserEntity")
        request.predicate = NSPredicate (format: "userName == %@", myStringValue!)
        do
        {
            let result = try context.fetch(request)
            if result.count > 0
            {
                let objectUpdate = result[0] as! NSManagedObject
                
                objectUpdate.setValue(nametf.text, forKey: "userName")
                objectUpdate.setValue(emailtf.text, forKey: "email")
                objectUpdate.setValue(Int64(agetf.text!), forKey: "age")
                do {
                    try context.save()
                    self.navigationController?.popViewController(animated: true)

                } catch {}
                print(objectUpdate)
                print("Object Saved.")
                
                
            }
        }
        catch
        {
            print(error)
        }
        
        
       
        
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
