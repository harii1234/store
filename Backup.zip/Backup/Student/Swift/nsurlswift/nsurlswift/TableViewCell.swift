//
//  TableViewCell.swift
//  nsurlswift
//
//  Created by hariprasath on 06/09/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var img: UIImageView!
    @IBOutlet var lab: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
