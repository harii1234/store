//
//  ViewController.swift
//  nsurlswift
//
//  Created by hariprasath on 30/08/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import SDWebImage


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
   
    

    var temp = NSArray()
    
    
    @IBOutlet var table: UITableView!
    @IBOutlet var collection: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
     
        let url = URL(string: "https://itunes.apple.com/search?term=jack+johnson")!
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
           
            guard let unwrappedData = data else { return }
            do {
                let dic:NSDictionary = try JSONSerialization.jsonObject(with: unwrappedData, options: .allowFragments) as! NSDictionary
                
                print(dic)
                
              
                    self.temp = dic.object(forKey: "results") as! NSArray

                
                
            } catch {
                print("json error: \(error)")
            }
          
            DispatchQueue.main.async {
                // Update UI
              //  self.table.reloadData()
                self.collection.reloadData()
            }

        }
        task.resume()

        
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        print(self.temp.count)
        return self.temp.count
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        myCell.backgroundColor = UIColor.gray
        
        let dic = self.temp[indexPath.row] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        myCell.lab.text = dic["trackCensoredName"] as? String
        myCell.lab?.textColor = UIColor.black
       // myCell.img?.backgroundColor = UIColor.red
        
       
        let url1 = URL(string: dic["artworkUrl100"] as! String)!
        myCell.img.sd_setImage(with: url1, completed: nil)
       
        
        
        //print(url1)
        
        return myCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return temp.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as! CollectionViewCell
        let dic = self.temp[indexPath.row] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
         let url1 = URL(string: dic["artworkUrl100"] as! String)!
        cell.img.sd_setImage(with: url1, completed: nil)
       cell.view.isHidden = true
        if indexPath.row == 3
        {
            cell.view.isHidden = false
            cell.lab.text = "+\(String(self.temp.count))"
        }
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       
        if indexPath.row == 3
        {
            let ViewController2 = self.storyboard?.instantiateViewController(withIdentifier: "ViewController2") as! ViewController2
            
            
            self.navigationController?.pushViewController(ViewController2, animated: true)
        }
       
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
                // Do something else
                return CGSize(width: 120 , height: 100)
      
    }
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets
    {
        
                return UIEdgeInsetsMake(10, 0, 10, 0)
    }

}

