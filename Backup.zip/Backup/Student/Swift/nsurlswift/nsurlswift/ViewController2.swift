//
//  ViewController2.swift
//  nsurlswift
//
//  Created by hariprasath on 17/04/18.
//  Copyright © 2018 hariprasath. All rights reserved.
//

import UIKit

class ViewController2: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    
    var temp = NSArray()
    
    
    @IBOutlet var table: UITableView!
    @IBOutlet var collection: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let url = URL(string: "https://itunes.apple.com/search?term=jack+johnson")!
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            
            guard let unwrappedData = data else { return }
            do {
                let dic:NSDictionary = try JSONSerialization.jsonObject(with: unwrappedData, options: .allowFragments) as! NSDictionary
                
                print(dic)
                
                
                self.temp = dic.object(forKey: "results") as! NSArray
                
                
                
            } catch {
                print("json error: \(error)")
            }
            
            DispatchQueue.main.async {
                // Update UI
                 self.table.reloadData()
                //self.collection.reloadData()
            }
            
        }
        task.resume()
        
        
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        print(self.temp.count)
        return self.temp.count
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        
        myCell.backgroundColor = UIColor.gray
        
        let dic = self.temp[indexPath.row] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        // myCell.img?.backgroundColor = UIColor.red
        
        
        let url1 = URL(string: dic["artworkUrl100"] as! String)!
        myCell.img.sd_setImage(with: url1, completed: nil)
        
        
        
        //print(url1)
        
        return myCell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(indexPath.row)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
