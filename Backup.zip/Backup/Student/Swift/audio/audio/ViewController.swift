//
//  ViewController.swift
//  AudioDemo
//
//  Created by hariprasath on 24/10/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import AVFoundation



class ViewController: UIViewController {
  
    
    var audioPlayer: AVAudioPlayer?
    var isPlaying = false
    var timer: Timer?
//    var trackTitle: UILabel!
//    var playedTime: UILabel!
    
    
    @IBOutlet var trackTitle: UILabel!
    @IBOutlet var playedTime: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        view.backgroundColor = UIColor.white
        isPlaying = false
        var mainBundle = Bundle.main
        var filePath: String? = mainBundle.path(forResource: "thestonefoxes-everybodyknows", ofType: "mp3")
        trackTitle.text = "The Stone Foxes - EveryBody Knows"
        var fileData = NSData(contentsOfFile: filePath!)
       
        do {
           // let player = try AVAudioPlayer(contentsOf: fileData)
            var error: Error? = nil
            audioPlayer = try? AVAudioPlayer(data: fileData! as Data)
            audioPlayer?.prepareToPlay()
        } catch {
            print(error)
        }

        
       


    }
    @IBAction func playOrPauseSound(_ sender: Any) {
        if isPlaying {
            // Music is currently playing
            print("Pausing Music")
            audioPlayer?.pause()
            isPlaying = false
        }
        else {
            // Music is currenty paused/stopped
            print("Playing music")
            audioPlayer?.play()
            isPlaying = true
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.updateTime), userInfo: nil, repeats: true)
        }
    }
    
    @IBAction func stopSound(_ sender: Any) {
        print("Stopping music")
        audioPlayer?.stop()
        audioPlayer?.currentTime = 0 as? TimeInterval ?? TimeInterval()
        isPlaying = false
    }
    
    @objc func updateTime() {
        let currentTime: TimeInterval = audioPlayer!.currentTime
        let minutes: Int = Int(floor(currentTime / 60))
    //    let seconds: Int = trunc(currentTime - minutes * 60)
        // update your UI with currentTime;
        playedTime.text = "\(minutes):%02d"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

