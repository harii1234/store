//
//  ViewController.swift
//  alamofiredemo
//
//  Created by hariprasath on 30/08/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import Alamofire


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var temp = NSArray()
    var dic = NSDictionary()

    
    @IBOutlet var tableview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

    }
    override func viewWillAppear(_ animated: Bool) {
        self.getUserDetails()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        print(self.temp.count)
        return self.temp.count
    }
    

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)   as! TableViewCell
        myCell.backgroundColor = UIColor.gray
        
        let dic = self.temp[indexPath.row] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        myCell.textLabel?.text = dic["trackCensoredName"] as! String
        myCell.textLabel?.textColor = UIColor.white
      
        
        let url = URL(string: dic["artworkUrl100"] as! String)
              print(url)

        myCell.img.backgroundColor = UIColor.red
        myCell.imageView?.image = UIImage (named: "http://is1.mzstatic.com/image/thumb/Music2/v4/a2/66/32/a2663205-663c-8301-eec7-57937c2d0878/source/100x100bb.jpg")
//        let url = URL(string:(dic2["artworkUrl100"] as! String))
//        let data = try? Data(contentsOf: url!)
//        let image: UIImage = UIImage(data: data!)!
//        myCell.imageView?.image = image
        
        
        
//        var url1 = URL(string: (dic2["artworkUrl100"] as? String)!)
//        myCell.imageView?.image = UIImage na
        

        
        
        return myCell
    }

    
    public func getUserDetails() {
        
        let url = "https://itunes.apple.com/search?term=jack+johnson"
        print("url: \(url)")
        
        Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
            
            
            .validate(statusCode: 200..<400)
            .responseJSON { response in
                
                switch response.result {
                case .success :
                    if let result = response.result.value {
                        let JSON = result as! NSDictionary
                        print("responds\(JSON)")
                       self.temp =  JSON.value(forKey: "results") as! NSArray
                        self.tableview.reloadData()
                        print(self.temp)
                        print(self.temp.count)
                        
                       
                  for value in self.temp
                   {
                  
                    self.dic = value as! NSDictionary
                    let name = self.dic.object(forKey: "trackCensoredName")
                    print(name!)
                    
                        }
                    
                    }
                    
                case .failure(let error): break
                
                    // sending to failure block
                    }

                    
                    
                }
        }
    }




