//
//  ViewController3.swift
//  alamofiredemo
//
//  Created by hariprasath on 05/09/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import Alamofire


class ViewController3: UIViewController,UITableViewDataSource,UITableViewDelegate {

    
    var result_arr = [String]()
    var temp_arr = [Products]()
    
    @IBOutlet var tableview: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getUserDetails()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        let temp:Products = self.temp_arr[section]

        result_arr = [temp.price!]
        
        return result_arr.count
        
    }
    
    
    public func numberOfSections(in tableView: UITableView) -> Int // Default is 1 if not implemented
        
    {
        
        return self.temp_arr.count
    }
    
    
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? // fixed font style. use custom view (UILabel) if you want something different
        
    {
        
       let temp:Products = self.temp_arr[section]
        
        let name = temp.title
        
        return name
    }
 
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)   as! TableViewCell
        myCell.backgroundColor = UIColor.gray
        
        let temp:Products = self.temp_arr[indexPath.row]

        
        myCell.textLabel?.text = temp.price
        
        
        return myCell
    }
    
    
    
    public func getUserDetails() {
        APIHandler.shared.getproduct(withSuccess: { (result) in
            //
            print(result)
            
            
            self.temp_arr = result as! [Products]
            
            DispatchQueue.main.async(execute: { () -> Void in
                // What you want to happen
                self.tableview.reloadData()
            })
            
        }) { (error) in
            //
        }
    }


}
