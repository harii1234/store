

import Foundation
 
/* For support, please feel free to contact me at  */

public class Translations {
	public var de : String?
	public var es : String?
	public var fr : String?
	public var ja : String?
	public var it : String?

/**
    Returns an array of models based on given dictionary.
    
    Sample usage:
    let translations_list = Translations.modelsFromDictionaryArray(someDictionaryArrayFromJSON)

    - parameter array:  NSArray from JSON dictionary.

    - returns: Array of Translations Instances.
*/
    public class func modelsFromDictionaryArray(array:NSArray) -> [Translations]
    {
        var models:[Translations] = []
        for item in array
        {
            models.append(Translations(dictionary: item as! NSDictionary)!)
        }
        return models
    }

/**
    Constructs the object based on the given dictionary.
    
    Sample usage:
    let translations = Translations(someDictionaryFromJSON)

    - parameter dictionary:  NSDictionary from JSON.

    - returns: Translations Instance.
*/
	required public init?(dictionary: NSDictionary) {

		de = dictionary["de"] as? String
		es = dictionary["es"] as? String
		fr = dictionary["fr"] as? String
		ja = dictionary["ja"] as? String
		it = dictionary["it"] as? String
	}

		
/**
    Returns the dictionary representation for the current instance.
    
    - returns: NSDictionary.
*/
	public func dictionaryRepresentation() -> NSDictionary {

		let dictionary = NSMutableDictionary()

		dictionary.setValue(self.de, forKey: "de")
		dictionary.setValue(self.es, forKey: "es")
		dictionary.setValue(self.fr, forKey: "fr")
		dictionary.setValue(self.ja, forKey: "ja")
		dictionary.setValue(self.it, forKey: "it")

		return dictionary
	}

}
