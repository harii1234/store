//
//  ViewController2.swift
//  alamofiredemo
//
//  Created by hariprasath on 01/09/17.
//  Copyright © 2017 hariprasath. All rights reserved.
//

import UIKit
import Alamofire


class ViewController2: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var result_arr = NSArray()
    @IBOutlet var tableview: UITableView!
    var page: Int = 0
    var isPageRefreshing: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getUserDetails()

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        let dic = self.result_arr [section] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        
        
        let spell:NSArray = dic["altSpellings"] as! NSArray
        
        return spell.count

    }
    
    
     public func numberOfSections(in tableView: UITableView) -> Int // Default is 1 if not implemented
    
     {
        
         return self.result_arr.count
    }
    
   
    public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? // fixed font style. use custom view (UILabel) if you want something different
    
     {
        
       let dic = self.result_arr[section] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
        
          let name:String = dic["name"] as! String
        
        return name
    }
    
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let  myCell  = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)   as! TableViewCell
        myCell.backgroundColor = UIColor.gray
        
        
        let dic = self.result_arr [indexPath.section] as? [AnyHashable: Any] ?? [AnyHashable: Any]()
    
       
        //myCell.textLabel?.text = "countryname\(dic["name"] as! String) & capital\(dic["capital"] as!String)"
        
        let spell:NSArray = dic["altSpellings"] as! NSArray
    
        
        var spellstr = String()
//        
//        for (item,element) in spell.enumerated()  {
//            print(element)
//            spellstr = element as! String
//            
//        }
        
        myCell.textLabel?.text = spell[indexPath.row] as! String
        
        return myCell
    }
   
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if tableview.contentOffset.y >= (tableview.contentSize.height - tableview.bounds.size.height) {
            if isPageRefreshing == false {
                isPageRefreshing = true
                self.getUserDetails()
                page += 1
                tableview.reloadData()
                print("called \(page)")
            }
        }
    }

    
    public func getUserDetails() {
        APIHandler.shared.getdetails(withSuccess: { (result) in
            //
            print(result)
           
            self.result_arr = result as! NSArray
           
            print(self.result_arr)
            
            DispatchQueue.main.async(execute: { () -> Void in
                // What you want to happen
                self.tableview.reloadData()
            })
            
        }) { (error) in
            //
        }
    }
    
}
