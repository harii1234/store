
import Foundation
 
/* For support, please feel free to contact me at  */

public class Detailroot {
	public var name : String?
	public var topLevelDomain : Array<String>?
	public var alpha2Code : String?
	public var alpha3Code : String?
	public var callingCodes : Array<Int>?
	public var capital : String?
	public var altSpellings : Array<String>?
	public var relevance : Int?
	public var region : String?
	public var subregion : String?
	public var population : Int?
	public var latlng : Array<Int>?
	public var demonym : String?
	public var area : Int?
	public var gini : Double?
	public var timezones : Array<String>?
	public var borders : Array<String>?
	public var nativeName : String?
	public var numericCode : Int?
	public var currencies : Array<String>?
	public var languages : Array<String>?
	public var translations : Translations?

/**
    Returns an array of models based on given dictionary.
    
    Sample usage:
    let Detailroot_list = Detailroot.modelsFromDictionaryArray(someDictionaryArrayFromJSON)

    - parameter array:  NSArray from JSON dictionary.

    - returns: Array of Detailroot Instances.
*/
    public class func modelsFromDictionaryArray(array:NSArray) -> [Detailroot]
    {
        var models:[Detailroot] = []
        for item in array
        {
            models.append(Detailroot(dictionary: item as! NSDictionary)!)
        }
        return models
    }

/**
    Constructs the object based on the given dictionary.
    
    Sample usage:
    let Detailroot = Detailroot(someDictionaryFromJSON)

    - parameter dictionary:  NSDictionary from JSON.

    - returns: Detailroot Instance.
*/
	required public init?(dictionary: NSDictionary) {

		name = dictionary["name"] as? String
		//if (dictionary["topLevelDomain"] != nil) { topLevelDomain = TopLevelDomain.modelsFromDictionaryArray(dictionary["topLevelDomain"] as! NSArray)
		alpha2Code = dictionary["alpha2Code"] as? String
		alpha3Code = dictionary["alpha3Code"] as? String
		//if (dictionary["callingCodes"] != nil) { callingCodes = CallingCodes.modelsFromDictionaryArray(dictionary["callingCodes"] as! NSArray) }
		capital = dictionary["capital"] as? String
		//if (dictionary["altSpellings"] != nil) { altSpellings = AltSpellings.modelsFromDictionaryArray(dictionary["altSpellings"] as! NSArray) }
		relevance = dictionary["relevance"] as? Int
		region = dictionary["region"] as? String
		subregion = dictionary["subregion"] as? String
		population = dictionary["population"] as? Int
		//if (dictionary["latlng"] != nil) { latlng = Latlng.modelsFromDictionaryArray(dictionary["latlng"] as! NSArray) }
		demonym = dictionary["demonym"] as? String
		area = dictionary["area"] as? Int
		gini = dictionary["gini"] as? Double
		//if (dictionary["timezones"] != nil) { timezones = Timezones.modelsFromDictionaryArray(dictionary["timezones"] as! NSArray) }
	//	if (dictionary["borders"] != nil) { borders = Borders.modelsFromDictionaryArray(dictionary["borders"] as! NSArray) }
		nativeName = dictionary["nativeName"] as? String
		numericCode = dictionary["numericCode"] as? Int
		//if (dictionary["currencies"] != nil) { currencies = Currencies.modelsFromDictionaryArray(dictionary["currencies"] as! NSArray) }
		//if (dictionary["languages"] != nil) { languages = Languages.modelsFromDictionaryArray(dictionary["languages"] as! NSArray) }
		if (dictionary["translations"] != nil) { translations = Translations(dictionary: dictionary["translations"] as! NSDictionary) }
	}

		
/**
    Returns the dictionary representation for the current instance.
    
    - returns: NSDictionary.
*/
	public func dictionaryRepresentation() -> NSDictionary {

		let dictionary = NSMutableDictionary()

		dictionary.setValue(self.name, forKey: "name")
		dictionary.setValue(self.alpha2Code, forKey: "alpha2Code")
		dictionary.setValue(self.alpha3Code, forKey: "alpha3Code")
		dictionary.setValue(self.capital, forKey: "capital")
		dictionary.setValue(self.relevance, forKey: "relevance")
		dictionary.setValue(self.region, forKey: "region")
		dictionary.setValue(self.subregion, forKey: "subregion")
		dictionary.setValue(self.population, forKey: "population")
		dictionary.setValue(self.demonym, forKey: "demonym")
		dictionary.setValue(self.area, forKey: "area")
		dictionary.setValue(self.gini, forKey: "gini")
		dictionary.setValue(self.nativeName, forKey: "nativeName")
		dictionary.setValue(self.numericCode, forKey: "numericCode")
		dictionary.setValue(self.translations?.dictionaryRepresentation(), forKey: "translations")

		return dictionary
	}

}
