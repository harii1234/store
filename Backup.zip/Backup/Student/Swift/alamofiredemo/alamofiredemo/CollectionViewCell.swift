//
//  CollectionViewCell.swift
//  nsurlswift
//
//  Created by hariprasath on 17/04/18.
//  Copyright © 2018 hariprasath. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var img: UIImageView!
    @IBOutlet var view: UIView!
    @IBOutlet var lab: UILabel!

    

}
