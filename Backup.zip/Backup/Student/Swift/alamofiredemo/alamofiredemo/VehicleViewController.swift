//
//  VehicleViewController.swift
//  nsurlswift
//
//  Created by hari Prasath on 08/08/18.
//  Copyright © 2018 hariprasath. All rights reserved.
//

import UIKit

class VehicleViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
   
    

    @IBOutlet var collection: UICollectionView!
    var temp = NSArray()
    var objDatahandler : DataHandler  = DataHandler()
    var newDict = NSDictionary()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Api_call()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return temp.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectioncell", for: indexPath) as! CollectionViewCell
        cell.lab.text = self.temp[indexPath.row] as! String
        return cell
        
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selected_index = self.temp[indexPath.row] as! String
        let bike_detail_arr:NSArray = newDict.value(forKey: selected_index) as! NSArray
        print(bike_detail_arr)
    }
    

    func Api_call()
    {
        let dic = NSMutableDictionary()
        dic["lat"] = "12.938345499999999"
        dic["lng"] = "77.6260959"
        dic["locationName"] = "Bangalore"
        dic["currencyId"] = "1517652398440298"
        objDatahandler.InputValues(storename: "", inputDic: dic, suburl: "", methodtype: "POST", classVc: self) { (dic_data) in
            
            let bike_dic:NSArray = dic_data.value(forKey: "bikes") as! NSArray
            let requestDataDict:NSDictionary = bike_dic[0]as!NSDictionary
            self.newDict = requestDataDict.object(forKey: "available") as! NSDictionary
            print("newDict is ---%@", self.newDict.allKeys)
            self.temp = self.newDict.allKeys as NSArray
            self.collection.reloadData()
           /* for i in 0...available_dic.count - 1{
                let dict_date: NSDictionary = available_dic .object(at: i) as! NSDictionary
                print(dict_date)

            }*/
            
        }

    }

}
